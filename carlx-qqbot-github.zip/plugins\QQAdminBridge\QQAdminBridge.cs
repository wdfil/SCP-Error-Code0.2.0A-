using System;
using System.Collections.Concurrent;
using System.ComponentModel;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Reflection;
using System.Text;
using System.Threading;
using CarLX.API.Features;
using CarLX.API.Interfaces;
using CarLX.PluginCommon;
using PlayerRoles;
using UnityEngine;

namespace CarLX.Plugins.QQAdminBridge
{
    public sealed class QQAdminBridgeConfig : IConfig
    {
        [Description("Enable the localhost admin bridge for the QQ bot.")]
        public bool IsEnabled { get; set; }

        public bool Debug { get; set; }

        [Description("Shared secret used by the QQ bot.")]
        public string Token { get; set; }

        [Description("Port offset from the game port. 10000 gives 17777/17778.")]
        public int PortOffset { get; set; }

        public QQAdminBridgeConfig()
        {
            IsEnabled = true;
            Debug = false;
            Token = "change-me-bridge-token";
            PortOffset = 10000;
        }
    }

    public sealed class QQAdminBridgePlugin : Plugin<QQAdminBridgeConfig>
    {
        private const string TickKey = "qqadminbridge.tick";
        private static readonly ConcurrentQueue<string> Actions = new ConcurrentQueue<string>();
        private static TcpListener _listener;
        private static Thread _thread;
        private static bool _active;
        private static string _token;

        public override string Name { get { return "QQAdminBridge"; } }
        public override string Prefix { get { return "qqadminbridge"; } }
        public override string Author { get { return "CarLX"; } }
        public override Version Version { get { return new Version(1, 0, 0); } }
        public override Version RequiredCarLXVersion { get { return new Version(6, 1, 0); } }

        public override void OnEnabled()
        {
            if (Config != null && !Config.IsEnabled)
            {
                base.OnEnabled();
                return;
            }

            _token = Config == null || string.IsNullOrEmpty(Config.Token) ? "change-me-bridge-token" : Config.Token;
            int port = (int)ServerStatic.ServerPort + (Config == null ? 10000 : Config.PortOffset);

            try
            {
                if (_listener != null) { try { _listener.Stop(); } catch { } _listener = null; }
                _listener = new TcpListener(IPAddress.Loopback, port);
                _listener.Server.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true);
                _listener.Start();
                _active = true;
                _thread = new Thread(Loop);
                _thread.IsBackground = true;
                _thread.Start();

                TickScheduler.EnsurePatched(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Logs", "qqadminbridge.log"));
                TickScheduler.Register(TickKey, 0.2f, ProcessActions);

                Log.Info("[QQAdminBridge] listening on 127.0.0.1:" + port);
            }
            catch (Exception exception)
            {
                Log.Error("[QQAdminBridge] start failed: " + exception.GetType().Name + ": " + exception.Message);
            }

            base.OnEnabled();
        }

        public override void OnDisabled()
        {
            _active = false;
            TickScheduler.Unregister(TickKey);

            try { if (_listener != null) _listener.Stop(); } catch { }
            _listener = null;
            _thread = null;

            base.OnDisabled();
        }

        private static void Loop()
        {
            while (_active && _listener != null)
            {
                TcpClient client = null;

                try
                {
                    client = _listener.AcceptTcpClient();
                    client.ReceiveTimeout = 3000;
                    Handle(client);
                }
                catch
                {
                }
                finally
                {
                    try { if (client != null) client.Close(); } catch { }
                }
            }
        }

        private static void Handle(TcpClient client)
        {
            using (NetworkStream stream = client.GetStream())
            using (StreamReader reader = new StreamReader(stream, Encoding.ASCII, false, 1024, true))
            {
                string requestLine = reader.ReadLine();
                if (string.IsNullOrEmpty(requestLine))
                {
                    Respond(stream, 400, "bad request");
                    return;
                }

                string[] parts = requestLine.Split(' ');
                if (parts.Length < 2)
                {
                    Respond(stream, 400, "bad request");
                    return;
                }

                string path = parts[1];
                string query = path;
                int question = path.IndexOf('?');

                if (question >= 0) query = path.Substring(question + 1);

                string token = QueryValue(query, "token");
                string action = QueryValue(query, "action");
                string text = QueryValue(query, "text");
                string name = QueryValue(query, "name");

                if (string.IsNullOrEmpty(token) || token != _token)
                {
                    Respond(stream, 403, "forbidden");
                    return;
                }

                if (action != "restart" && action != "start" && action != "lock" && action != "unlock" && action != "cassie" && action != "globalchat"
                    && action != "warhead_start" && action != "warhead_stop" && action != "warhead_lock" && action != "warhead_unlock"
                    && action != "dummy" && action != "reloadra" && action != "hammerwave" && action != "serpent" && action != "announce")
                {
                    Respond(stream, 400, "unknown action");
                    return;
                }

                if (action == "globalchat")
                {
                    if (string.IsNullOrEmpty(text)) { Respond(stream, 400, "empty text"); return; }
                    if (text.Length > 300) text = text.Substring(0, 300);
                    Actions.Enqueue("globalchat|" + (name ?? "未知玩家") + "|" + text);
                    Respond(stream, 200, "queued:globalchat");
                    return;
                }

                if (action == "cassie")
                {
                    if (string.IsNullOrEmpty(text)) { Respond(stream, 400, "empty text"); return; }
                    if (text.Length > 300) text = text.Substring(0, 300);
                    Actions.Enqueue("cassie|" + text);
                    Respond(stream, 200, "queued:cassie");
                    return;
                }

                Actions.Enqueue(action);
                Respond(stream, 200, "queued:" + action);
            }
        }

        private static string QueryValue(string query, string key)
        {
            if (string.IsNullOrEmpty(query)) return null;

            string[] pairs = query.Split('&');

            for (int i = 0; i < pairs.Length; i++)
            {
                string[] pair = pairs[i].Split(new char[] { '=' }, 2);
                if (pair.Length != 2) continue;
                if (!string.Equals(pair[0], key, StringComparison.OrdinalIgnoreCase)) continue;

                return Uri.UnescapeDataString(pair[1]);
            }

            return null;
        }

        private static void Respond(NetworkStream stream, int status, string body)
        {
            byte[] data = Encoding.UTF8.GetBytes(body);
            string reason = status == 200 ? "OK" : status == 403 ? "Forbidden" : "Bad Request";
            string header = "HTTP/1.1 " + status + " " + reason + "\r\n"
                            + "Content-Type: text/plain; charset=utf-8\r\n"
                            + "Content-Length: " + data.Length + "\r\n"
                            + "Connection: close\r\n\r\n";

            byte[] headerData = Encoding.ASCII.GetBytes(header);
            stream.Write(headerData, 0, headerData.Length);
            stream.Write(data, 0, data.Length);
            stream.Flush();
        }

        private static void BroadcastGlobal(string name, string text)
        {
            string formatted = "[公共] " + name + "：[全服] " + text;
            WriteGlobal("start " + formatted);

            try
            {
                foreach (Assembly assembly in AppDomain.CurrentDomain.GetAssemblies())
                {
                    Type chatType = assembly.GetType("HuanMiao.Feature.Chat", false);
                    if (chatType == null) continue;

                    PropertyInfo instanceProperty = chatType.GetProperty("Instance", BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic);
                    object instance = instanceProperty == null ? null : instanceProperty.GetValue(null, null);

                    if (instance == null)
                    {
                        WriteGlobal("Chat.Instance null in " + assembly.GetName().Name);
                        continue;
                    }

                    MethodInfo send = null;

                    foreach (MethodInfo method in chatType.GetMethods(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic))
                    {
                        if (method.Name != "SendPublic") continue;

                        ParameterInfo[] parameters = method.GetParameters();
                        if (parameters.Length == 4 && parameters[0].ParameterType == typeof(Player)
                            && parameters[1].ParameterType == typeof(string)
                            && parameters[2].ParameterType == typeof(string))
                        {
                            send = method;
                            break;
                        }
                    }

                    if (send == null)
                    {
                        WriteGlobal("Chat.SendPublic missing in " + assembly.GetName().Name);
                        continue;
                    }

                    object[] arguments = new object[] { null, name, "[全服] " + text, null };
                    object result = send.Invoke(instance, arguments);

                    if (result is bool && (bool)result)
                    {
                        WriteGlobal("Chat.SendPublic OK in " + assembly.GetName().Name);
                        Log.Info("[QQAdminBridge] global chat hint sent: " + formatted);
                        return;
                    }

                    WriteGlobal("Chat.SendPublic returned " + (result == null ? "null" : result.ToString()) + " in " + assembly.GetName().Name);
                }
            }
            catch (Exception exception)
            {
                WriteGlobal("Chat.SendPublic exception: " + exception.GetType().Name + ": " + exception.Message);
                Log.Error("[QQAdminBridge] Chat.SendPublic failed: " + exception.GetType().Name + ": " + exception.Message);
            }

            try
            {
                Type featureType = null;
                Type channelType = null;

                foreach (Assembly assembly in AppDomain.CurrentDomain.GetAssemblies())
                {
                    if (featureType == null) featureType = assembly.GetType("HuanMiao.Feature.HintFeature", false);
                    if (channelType == null) channelType = assembly.GetType("HuanMiao.Feature.HintChannel", false);
                }

                if (featureType == null || channelType == null) return;

                PropertyInfo instanceProperty = featureType.GetProperty("Instance", BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic);
                object instance = instanceProperty == null ? null : instanceProperty.GetValue(null, null);
                if (instance == null) return;

                object channel = Enum.Parse(channelType, "Chat");
                WriteGlobal("using HintFeature fallback");

                foreach (MethodInfo method in featureType.GetMethods(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic))
                {
                    if (method.Name != "Show") continue;

                    ParameterInfo[] parameters = method.GetParameters();
                    if (parameters.Length != 4 || parameters[1].ParameterType != channelType
                        || parameters[2].ParameterType != typeof(string) || parameters[3].ParameterType != typeof(float)) continue;

                    foreach (ReferenceHub hub in ReferenceHub.AllHubs)
                    {
                        if (hub == null) continue;

                        try { method.Invoke(instance, new object[] { hub, channel, formatted, 6f }); } catch { }
                    }

                    Log.Info("[QQAdminBridge] global chat HintFeature sent: " + formatted);
                    return;
                }
            }
            catch (Exception exception)
            {
                Log.Error("[QQAdminBridge] HintFeature failed: " + exception.GetType().Name + ": " + exception.Message);
            }
        }

        private static void SpawnDummy()
        {
            ReferenceHub anchor = null;

            foreach (ReferenceHub hub in ReferenceHub.AllHubs)
            {
                if (hub == null || hub == ReferenceHub.HostHub) continue;
                if (hub.connectionToClient == null) continue;
                anchor = hub;
                break;
            }

            if (anchor == null)
            {
                Log.Info("[QQAdminBridge] dummy skipped: no online player anchor");
                return;
            }

            Vector3 position = anchor.transform.position + anchor.transform.forward * 1.5f;
            ReferenceHub dummy = ServerDummy.Spawn(RoleTypeId.ClassD, position, anchor.transform.rotation);
            Log.Info("[QQAdminBridge] spawned dummy id=" + (dummy == null ? "?" : dummy.PlayerId.ToString()) + " near " + anchor.PlayerId);
        }

        private static void WriteGlobal(string message)
        {
            try
            {
                File.AppendAllText(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Logs", "qqadminbridge_global.log"),
                    DateTime.Now.ToString("HH:mm:ss.fff") + " " + message + Environment.NewLine);
            }
            catch
            {
            }
        }

        private static void ProcessActions()
        {
            string action;

            while (Actions.TryDequeue(out action))
            {
                try
                {
                    if (action.StartsWith("globalchat|", StringComparison.Ordinal))
                    {
                        string payload = action.Substring(11);
                        int split = payload.IndexOf('|');
                        string name = split < 0 ? "未知玩家" : payload.Substring(0, split);
                        string text = split < 0 ? payload : payload.Substring(split + 1);

                        BroadcastGlobal(name, text);
                        Log.Info("[QQAdminBridge] global chat " + name + ": " + text);
                        continue;
                    }

                    if (action.StartsWith("cassie|", StringComparison.Ordinal))
                    {
                        string text = action.Substring(7);

                        // Run the real remote-admin command. ".G7" is a CASSIE
                        // easter egg that only fires through the command path.
                        text = text.Replace('\r', ' ').Replace('\n', ' ').Trim();

                        if (text.Length > 300) text = text.Substring(0, 300);

                        ServerConsole.EnterCommand("cassie_sl " + text, ServerConsole.Scs);
                        Log.Info("[QQAdminBridge] cassie command: cassie_sl " + text);
                        continue;
                    }

                    if (action == "restart") Round.RestartSilently();
                    else if (action == "start") Round.Start();
                    else if (action == "lock") Round.IsLocked = true;
                    else if (action == "unlock") Round.IsLocked = false;
                    else if (action == "warhead_start") Warhead.Start();
                    else if (action == "warhead_stop") Warhead.Stop();
                    else if (action == "warhead_lock") Warhead.IsLocked = true;
                    else if (action == "warhead_unlock") Warhead.IsLocked = false;
                    else if (action == "dummy") SpawnDummy();
                    else if (action == "reloadra") ReloadRaConfig();
                    else if (action == "hammerwave") DeployPlugin("CarLX.Plugins.HammerWave.HammerWavePlugin");
                    else if (action == "serpent") DeployPlugin("CarLX.Plugins.SerpentHand.SerpentHandPlugin");
                    else if (action == "announce") PlayAnnouncement();

                    Log.Info("[QQAdminBridge] executed " + action);
                }
                catch (Exception exception)
                {
                    Log.Error("[QQAdminBridge] " + action + " failed: " + exception.GetType().Name + ": " + exception.Message);
                }
            }
        }

        private static void PlayAnnouncement()
        {
            try
            {
                string announceLog = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Logs", "qqadminbridge.log");

                File.AppendAllText(announceLog, DateTime.Now.ToString("HH:mm:ss.fff") + "  announce invoked" + Environment.NewLine);
                Vector3 position = new Vector3(126.914f, 995.456f, -45.418f);

                Type type = null;

                // 重载后旧程序集仍留在 AppDomain，取最后一个（最新）才是当前生效的实例。
                foreach (Assembly assembly in AppDomain.CurrentDomain.GetAssemblies())
                {
                    Type candidate = null;

                    try { candidate = assembly.GetType("CarLX.Plugins.DummyVoice.DummyVoicePlugin"); } catch { }
                    if (candidate != null) type = candidate;
                }

                if (type != null)
                {
                    MethodInfo method = type.GetMethod("PlayAnnouncement", BindingFlags.Static | BindingFlags.NonPublic | BindingFlags.Public);

                    if (method != null)
                    {
                        File.AppendAllText(announceLog, "  invoking " + method.DeclaringType.Assembly.GetName().Name + Environment.NewLine);
                        method.Invoke(null, new object[] { "hammer-announce.wav", position });
                        Log.Info("[QQAdminBridge] announcement invoked");
                        return;
                    }
                }

                File.AppendAllText(announceLog, "  DummyVoice not loaded" + Environment.NewLine);

                Log.Error("[QQAdminBridge] DummyVoice not loaded");
            }
            catch (Exception exception)
            {
                Log.Error("[QQAdminBridge] announce failed: " + exception.GetType().Name + ": " + exception.Message);
            }
        }

        private static void ReloadRaConfig()
        {
            try { GameCore.ConfigFile.ReloadGameConfigs(false); } catch { }

            BindingFlags flags = BindingFlags.Static | BindingFlags.NonPublic | BindingFlags.Public;
            Type serverStatic = typeof(ServerStatic);

            FieldInfo rolesField = serverStatic.GetField("RolesConfig", flags);
            FieldInfo sharedField = serverStatic.GetField("SharedGroupsConfig", flags);
            FieldInfo sharedMembersField = serverStatic.GetField("SharedGroupsMembersConfig", flags);
            FieldInfo handlerField = serverStatic.GetField("PermissionsHandler", flags);

            if (rolesField == null || handlerField == null)
            {
                Log.Error("[QQAdminBridge] reloadra fields not found");
                return;
            }

            string path = FileManager.GetAppFolder(true, true, null) + "config_remoteadmin.txt";
            object[] args = new object[] { new YamlConfig(path), null, null };
            object handler = Activator.CreateInstance(typeof(PermissionsHandler), args);

            rolesField.SetValue(null, args[0]);
            if (sharedField != null) sharedField.SetValue(null, args[1]);
            if (sharedMembersField != null) sharedMembersField.SetValue(null, args[2]);
            handlerField.SetValue(null, handler);

            MethodInfo getUserGroup = handler.GetType().GetMethod("GetUserGroup");
            int applied = 0;

            foreach (ReferenceHub hub in ReferenceHub.AllHubs)
            {
                if (hub == null || hub.serverRoles == null) continue;

                string uid = null;
                try { uid = hub.characterClassManager == null ? null : hub.characterClassManager.UserId; } catch { }
                if (string.IsNullOrEmpty(uid) || getUserGroup == null) continue;

                object group = null;
                try { group = getUserGroup.Invoke(handler, new object[] { uid }); } catch { }
                if (group == null) continue;

                try
                {
                    hub.serverRoles.SetGroup((UserGroup)group, false, false);
                    applied++;
                }
                catch
                {
                }
            }

            Log.Info("[QQAdminBridge] reloadra applied groups=" + applied);
        }

        private static void DeployPlugin(string typeName)
        {
            Type type = null;

            foreach (Assembly assembly in AppDomain.CurrentDomain.GetAssemblies())
            {
                Type candidate = null;

                try { candidate = assembly.GetType(typeName); } catch { }
                if (candidate != null) type = candidate;
            }

            if (type == null)
            {
                Log.Error("[QQAdminBridge] plugin type not found: " + typeName);
                return;
            }

            MethodInfo method = type.GetMethod("Deploy", BindingFlags.Static | BindingFlags.NonPublic | BindingFlags.Public);

            if (method == null)
            {
                Log.Error("[QQAdminBridge] Deploy method not found: " + typeName);
                return;
            }

            object result = method.Invoke(null, null);
            int spawned = result is int ? (int)result : -1;
            Log.Info("[QQAdminBridge] " + typeName + " deployed=" + spawned);
        }
    }
}
