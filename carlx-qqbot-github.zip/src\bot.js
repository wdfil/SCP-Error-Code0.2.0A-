'use strict';

const fs = require('fs');
const path = require('path');
const os = require('os');
const { execFileSync } = require('child_process');

const ROOT = __dirname;
const CONFIG_PATH = path.join(ROOT, 'config.json');
const LOG_PATH = path.join(ROOT, 'bot.log');
const API_BASE = 'https://api.bot.qq.com';
const TOKEN_URL = 'https://api.bot.qq.com/app/getAppAccessToken';
  let QQ_APP_ID = '';   // 从 config.json 的 appId 读取，避免把 AppID 写死在源码里

const SERVER_ROOTS = {
  7777: 'D:/二服',
  7778: 'D:/一服',
  7779: 'D:/三服'
};

const SERVER_PORTS = [7777, 7778, 7779];

function serverLabel(port) {
  const p = Number(port);
  if (p === 7777) return '二服';
  if (p === 7778) return '一服';
  if (p === 7779) return '三服';
  return String(port);
}

function serverDataPath(port, name) {
  const root = SERVER_ROOTS[port] || SERVER_ROOTS[7777];
  return path.join(root, 'CarLX', 'Data', name);
}

function serverLogPath(port, name) {
  const root = SERVER_ROOTS[port] || SERVER_ROOTS[7777];
  return path.join(root, 'Logs', name);
}

const TEST_WHITELIST_PATH = 'D:/一服/CarLX/Data/test-whitelist.txt';

function addTestWhitelistUid(uid) {
  try {
    const dir = path.dirname(TEST_WHITELIST_PATH);
    fs.mkdirSync(dir, { recursive: true });

    let lines = [];
    if (fs.existsSync(TEST_WHITELIST_PATH)) {
      lines = fs.readFileSync(TEST_WHITELIST_PATH, 'utf8').replace(/^\uFEFF/, '').split(/\r?\n/);
    }

    const target = normalizeUid(uid).trim().toLowerCase();
    for (const line of lines) {
      if (line.trim().toLowerCase() === target) return 'exists';
    }

    fs.appendFileSync(TEST_WHITELIST_PATH, normalizeUid(uid).trim() + '\n', 'utf8');
    return 'added';
  } catch (_) {
    return 'error';
  }
}

let cachedToken = null;
let cachedTokenUntil = 0;

function log(message) {
  const line = new Date().toLocaleString('zh-CN', { hour12: false }) + '  ' + message;
  console.log(line);
  try {
    fs.appendFileSync(LOG_PATH, line + '\r\n', 'utf8');
  } catch (_) {
  }
}

function loadConfig() {
  const raw = fs.readFileSync(CONFIG_PATH, 'utf8').replace(/^\uFEFF/, '');
  return JSON.parse(raw);
}

function apiBase() {
  return API_BASE;
}

async function getAccessToken(config, force) {
  if (!config.appId || !config.clientSecret) {
    throw new Error('config.json 里的 appId / clientSecret 还没有填写');
  }

  if (!force && cachedToken && Date.now() < cachedTokenUntil) {
    return cachedToken;
  }

  const response = await fetch(TOKEN_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      appId: String(config.appId),
      clientSecret: String(config.clientSecret)
    })
  });

  const text = await response.text();
  let data;

  try {
    data = JSON.parse(text);
  } catch (_) {
    throw new Error('获取 access_token 返回非 JSON: ' + text.slice(0, 300));
  }

  if (!response.ok || !data.access_token) {
    throw new Error('获取 access_token 失败: HTTP ' + response.status + ' ' + text.slice(0, 500));
  }

  cachedToken = data.access_token;
  cachedTokenUntil = Date.now() + Math.max(60, Number(data.expires_in || 7200) - 60) * 1000;
  return cachedToken;
}

function decodeName(value) {
  try {
    return decodeURIComponent(value || '');
  } catch (_) {
    return value || '';
  }
}

function platformOf(uid, name, overrides) {
  const text = String(name || '');
  const id = String(uid || '');
  const map = overrides || {};

  if (map[text]) return map[text];
  if (map[id]) return map[id];

  if (/^\(PC\)/i.test(text)) return 'PC';
  if (/@steam/i.test(id) || /@discord/i.test(id) || /%40steam/i.test(id)) return 'PC';

  if (/@device/i.test(id) || /%40device/i.test(id)) {
    const raw = id.split('@')[0].split('%40')[0];
    return raw.length >= 24 ? 'PC' : '手机';
  }

  return '未知';
}

function readLeaderboard(file, limit, overrides) {
  const rows = [];

  try {
    if (!fs.existsSync(file)) return rows;

    const text = fs.readFileSync(file, 'utf8').replace(/^\uFEFF/, '');
    const lines = text.split(/\r?\n/);

    for (const line of lines) {
      if (!line.trim()) continue;

      const parts = line.split('\t');
      if (parts.length < 5) continue;

      const uid = decodeName(parts[0] || '');
      const name = decodeName(parts[1]).trim();

      let humanKills = parseInt(parts[3], 10);
      let scpKills = 0;
      let deaths = 0;
      let assists = 0;

      if (parts.length >= 8) {
        scpKills = parseInt(parts[4], 10);
        deaths = parseInt(parts[5], 10);
        assists = parseInt(parts[6], 10);
      } else {
        scpKills = parseInt(parts[4], 10);
      }

      if (!Number.isFinite(humanKills)) continue;
      if (!Number.isFinite(scpKills)) scpKills = 0;
      if (!Number.isFinite(deaths)) deaths = 0;
      if (!Number.isFinite(assists)) assists = 0;

      const kills = humanKills + scpKills;
      const points = humanKills * 100 + scpKills * 150 + assists * 50 - deaths * 20;

      if (!name) continue;

      rows.push({
        name,
        key: uid,
        humanKills,
        scpKills,
        kills,
        deaths,
        assists,
        points,
        platform: platformOf(uid, name, overrides)
      });
    }
  } catch (error) {
    log('读取击杀榜失败: ' + error.message);
  }

  rows.sort((a, b) => b.kills - a.kills || a.deaths - b.deaths || a.name.localeCompare(b.name));
  return rows.slice(0, Math.max(1, Math.min(500, limit || 10)));
}

function readOnlineCount(port) {
  const file = serverDataPath(port, 'online-' + port + '.txt');

  try {
    const stat = fs.statSync(file);
    const text = fs.readFileSync(file, 'utf8').trim();
    const parts = text.split('|');
    const count = parseInt(parts[0], 10);
    const age = Date.now() - stat.mtimeMs;
    const hasCpu = parts.length >= 3;
    const hasAdmins = parts.length >= 4;
    const hasRound = parts.length >= 6;
    const cpu = hasCpu ? parts[1] : '0.0';
    const admins = hasAdmins ? parseInt(parts[2], 10) : 0;
    const scps = hasRound ? parseInt(parts[3], 10) : 0;
    const elapsed = hasRound ? parseInt(parts[4], 10) : 0;

    return {
      port: port,
      label: serverLabel(port),
      count: Number.isFinite(count) ? count : 0,
      max: 30,
      cpu: cpu,
      admins: Number.isFinite(admins) ? admins : 0,
      scps: Number.isFinite(scps) ? scps : 0,
      elapsed: Number.isFinite(elapsed) ? elapsed : 0,
      time: (hasRound ? parts[5] : hasAdmins ? parts[3] : hasCpu ? parts[2] : parts[1]) || stat.mtime.toLocaleString('zh-CN', { hour12: false }),
      online: age < 15000
    };
  } catch (_) {
    return { port: port, label: serverLabel(port), count: 0, max: 30, cpu: '0.0', admins: 0, scps: 0, elapsed: 0, time: '无数据', online: false };
  }
}

function escapeHtml(value) {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function cpuSnapshot() {
  let idle = 0;
  let total = 0;

  for (const cpu of os.cpus()) {
    idle += cpu.times.idle;
    total += cpu.times.user + cpu.times.nice + cpu.times.sys + cpu.times.idle + cpu.times.irq;
  }

  return { idle: idle, total: total };
}

let cpuPrevious = cpuSnapshot();
let totalCpuPercent = 0;

setInterval(() => {
  const current = cpuSnapshot();
  const idleDelta = current.idle - cpuPrevious.idle;
  const totalDelta = current.total - cpuPrevious.total;

  if (totalDelta > 0) {
    totalCpuPercent = Math.max(0, Math.min(100, (1 - idleDelta / totalDelta) * 100));
  }

  cpuPrevious = current;
}, 1000).unref();

function getKillCollectionStatus() {
  const hour = new Date().getHours();
  const paused = hour >= 23 || hour < 6;

  return {
    paused: paused,
    text: paused ? '停止收集击杀' : '正在收集击杀'
  };
}

const LIGHT_UI_CSS = `
html,body{background:linear-gradient(135deg,#f4f0ff,#eef8ff 55%,#fff4f4)!important;background-image:none!important;color:#1d2433!important}
.title{color:#1d2433!important}
.sub,.foot,.meta,.match,.admins,.total{color:#6f7890!important}
.total{border-color:#e5e1f5!important;background:rgba(255,255,255,.65)!important}
.line{background:linear-gradient(90deg,#b9a8f5,rgba(185,168,245,.05))!important}
.card,.board{background:rgba(255,255,255,.94)!important;border-color:rgba(120,100,200,.14)!important;box-shadow:0 18px 50px rgba(80,70,140,.10)!important}
.port{color:#5b4bb7!important}
.count{color:#5b4bb7!important}
.match b,.admins b,.cpu b{color:#138a63!important}
.board-head{color:#1d2433!important;border-color:#eceefa!important;background:#fff!important}
.name{color:#1d2433!important}
th{color:#7d859b!important;background:#f7f8fd!important;border-color:#eceefa!important}
td{color:#1d2433!important;border-color:#eef0f8!important}
.zone-row td{background:#f3efff!important;color:#6d5bd0!important;border-color:#e8e2fb!important}
.zone-row.secondary td{background:#f8fafc!important;color:#8a91a6!important}
.qualify td{background:linear-gradient(90deg,rgba(156,124,244,.08),transparent 55%)!important}
.server{color:#138a63!important}
.platform{color:#69728a!important}
.kills{color:#138a63!important}
.deaths{color:#c05a72!important}
.points{color:#6d5bd0!important}
.names .name{background:#f7f8fd!important;border-color:#eceefa!important;color:#3f4960!important}
.empty{color:#8a91a6!important}
.collect-status.active{color:#138a63!important;background:#e9fbf3!important;border-color:#c9f1e2!important}
.collect-status.paused{color:#c05a72!important;background:#fff0f2!important;border-color:#ffd8de!important}
`;

function applyLightUi(html) {
  return String(html || '').replace('</style>', LIGHT_UI_CSS + '</style>');
}
function buildCxHtml(rows, ranking, cpuPercent, pcMode) {
  const killStatus = getKillCollectionStatus();
  const pc = !!pcMode;
  const cards = rows.map((row) => {
    const status = row.online ? '在线' : '离线';
    const color = row.online ? '#5eead4' : '#fb7185';
    return '<div class="card">'
      + '<div class="port">' + escapeHtml(row.label) + ' · ' + escapeHtml(row.port) + '</div>'
      + '<div class="count">' + row.count + '<span>/' + row.max + ' 人</span></div>'
      + '<div class="admins">管理在线 <b>' + row.admins + '</b></div>'
      + '<div class="match">SCP <b>' + row.scps + '</b> · 对局已开始 <b>' + Math.floor(row.elapsed / 60) + '</b> 分钟</div>'
      + '<div class="meta" style="color:' + color + '">' + status + ' · ' + escapeHtml(row.time) + '</div>'
      + '</div>';
  }).join('');

  let rankRows = '';
  ranking.forEach((row, index) => {
    const rankClass = index === 0 ? 'gold' : index === 1 ? 'silver' : index === 2 ? 'bronze' : '';

    if (pc) {
      rankRows += '<tr>'
        + '<td class="rank ' + rankClass + '">' + (index + 1) + '</td>'
        + '<td class="name">' + escapeHtml(row.name) + '</td>'
        + '<td class="platform">' + escapeHtml(row.platform) + '</td>'
        + '<td class="server">' + escapeHtml(row.server) + '</td>'
        + '<td class="kills">' + row.kills + '</td>'
        + '<td class="deaths">' + row.deaths + '</td>'
        + '</tr>';
      return;
    }

    rankRows += '<tr>'
      + '<td class="rank ' + rankClass + '">' + (index + 1) + '</td>'
      + '<td class="name">' + escapeHtml(row.name) + '</td>'
      + '<td class="platform">' + escapeHtml(row.platform) + '</td>'
      + '<td class="server">' + escapeHtml(row.server) + '</td>'
      + '<td class="points">' + row.points + '</td>'
      + '</tr>';
  });

  const title = pc ? '一服 / 二服 / 三服 在线人数与击杀榜' : '一服 / 二服在线人数与综合积分榜';
  const boardHead = pc ? '击杀榜 · 手机端 + PC端 <span class="collect-status active">全部玩家</span>' : '综合积分榜 <span class="collect-status ' + (killStatus.paused ? 'paused' : 'active') + '">' + killStatus.text + '</span>';
  const thead = pc
    ? '<th>排名</th><th>玩家</th><th>平台</th><th>服务器</th><th style="text-align:right">击杀</th><th style="text-align:right">死亡</th>'
    : '<th>排名</th><th>玩家</th><th>平台</th><th>服务器</th><th style="text-align:right">积分</th>';

  return '<!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8">'
    + '<style>'
    + 'html,body{margin:0;padding:0;background:#070b12;color:#e9eef8;font-family:"Microsoft YaHei",system-ui,sans-serif}'
    + 'body{width:900px;height:960px;overflow:hidden;background:linear-gradient(rgba(7,11,18,.70),rgba(7,11,18,.84)),url(bg.jpg) center/cover no-repeat,#070b12}'
    + '.page{padding:34px 52px;box-sizing:border-box}'
    + '.title{font-size:28px;font-weight:800;letter-spacing:.04em}'
    + '.sub{margin-top:7px;color:#7f8da3;font-size:13px}'
    + '.total{display:inline-block;margin-top:14px;padding:7px 12px;border:1px solid rgba(94,234,212,.22);border-radius:999px;color:#8b98ad;font-size:13px}'
    + '.total b{color:#5eead4;font-weight:800}'
    + '.line{height:1px;background:linear-gradient(90deg,rgba(94,234,212,.5),rgba(255,255,255,.04));margin:20px 0}'
    + '.cards{display:flex;gap:24px}'
    + '.card{flex:1;padding:20px 24px;border:1px solid rgba(255,255,255,.09);border-radius:18px;background:linear-gradient(180deg,rgba(18,27,42,.95),rgba(10,16,26,.95))}'
    + '.port{font-size:16px;color:#9ff3e4;letter-spacing:.1em}'
    + '.count{margin-top:12px;font-size:58px;line-height:1;font-weight:800;color:#f3c969;font-variant-numeric:tabular-nums}'
    + '.count span{font-size:18px;margin-left:8px;color:#d9e2f0}'
    + '.admins{margin-top:9px;font-size:13px;color:#8b98ad}'
    + '.admins b{color:#f3c969;font-weight:800}'
    + '.match{margin-top:6px;font-size:12.5px;color:#7f8da3}'
    + '.match b{color:#9ff3e4;font-weight:700}'
    + '.cpu{margin-top:8px;font-size:12.5px;color:#7f8da3}'
    + '.cpu b{color:#9ff3e4;font-weight:700}'
    + '.meta{margin-top:10px;font-size:12.5px}'
    + '.board{margin-top:22px;border:1px solid rgba(255,255,255,.08);border-radius:16px;overflow:hidden;background:rgba(10,16,26,.9)}'
    + '.board-head{padding:14px 20px;font-size:16px;font-weight:700;color:#e9eef8;border-bottom:1px solid rgba(255,255,255,.06)}'
    + '.collect-status{float:right;font-size:11px;font-weight:600;letter-spacing:.04em;padding:3px 8px;border-radius:999px}'
    + '.collect-status.active{color:#5eead4;background:rgba(94,234,212,.12);border:1px solid rgba(94,234,212,.25)}'
    + '.collect-status.paused{color:#f08a8a;background:rgba(240,138,138,.12);border:1px solid rgba(240,138,138,.25)}'
    + 'table{width:100%;border-collapse:collapse}'
    + 'th{text-align:left;padding:9px 18px;color:#7f8da3;font-size:11px;letter-spacing:.1em;border-bottom:1px solid rgba(255,255,255,.05)}'
    + 'td{padding:8px 18px;border-bottom:1px solid rgba(255,255,255,.035);font-size:13px}'
    + 'tr:last-child td{border-bottom:0}'
    + '.rank{width:42px;font-weight:800;color:#8b98ad}'
    + '.rank.gold{color:#f3c969}.rank.silver{color:#c8d3e2}.rank.bronze{color:#d79362}'
    + '.zone-row td{padding:7px 18px;background:rgba(243,201,105,.1);color:#f3c969;font-size:11px;font-weight:700;letter-spacing:.12em;border-bottom:1px solid rgba(243,201,105,.14)}'
    + '.zone-row.secondary td{background:rgba(255,255,255,.035);color:#7f8da3;border-bottom-color:rgba(255,255,255,.04)}'
    + '.qualify td{background:linear-gradient(90deg,rgba(243,201,105,.055),transparent 55%)}'
    + '.name{font-weight:600}.platform{color:#c8d3e2;font-size:12px;width:56px}.server{color:#9ff3e4;font-size:12px;width:46px}.points{color:#f3c969;font-weight:800;text-align:right;width:62px}.kills{color:#5eead4;font-weight:700;text-align:right;width:48px}.assists{color:#c8d3e2;text-align:right;width:48px}.scp{color:#9ff3e4;text-align:right;width:46px}.deaths{color:#a97b82;text-align:right;width:52px}'
    + '.rank-table th,.rank-table td{padding-left:9px;padding-right:9px}'
    + '.foot{margin-top:14px;color:#5e6b80;font-size:11px}'
    + '</style></head><body><div class="page">'
    + '<div class="title">' + title + '</div>'
    + '<div class="sub">7778 一服 · 7777 二服 本地实时查询</div>'
    + '<div class="total">总占用率 <b>' + escapeHtml(cpuPercent.toFixed(1)) + '%</b></div>'
    + '<div class="line"></div>'
    + '<div class="cards">' + cards + '</div>'
    + '<div class="board"><div class="board-head">' + boardHead + '</div>'
    + '<table class="rank-table"><thead><tr>' + thead + '</tr></thead>'
    + '<tbody>' + rankRows + '</tbody></table></div>'
    + '<div class="foot">生成时间 ' + escapeHtml(new Date().toLocaleString('zh-CN', { hour12: false })) + '</div>'
    + '</div></body></html>';
}

function isLeaderboardFinal(config) {
  if (!config) return false;
  if (new Date().getHours() >= 20) return true;

  const files = [config.leaderboardFile, config.leaderboardFile7778, config.leaderboardFile7779];
  if (files.some((file) => file && fs.existsSync(path.dirname(file) + '/killstats-finalists.txt'))) return true;
  return files.some((file) => file && fs.existsSync(file + '.final'));
}

function readRanking(config) {
  // 不再使用淘汰赛（final）概念：始终按配置的 topCount 输出完整榜单
  const limit = config && config.topCount ? config.topCount : 10;
  const merged = new Map();

  function addRows(list, server) {
    for (const row of list) {
      const key = (row.name || '').trim().toLowerCase();
      if (!key) continue;

      let item = merged.get(key);

      if (!item) {
        item = {
          name: row.name,
          humanKills: row.humanKills,
          scpKills: row.scpKills,
          kills: row.kills,
          deaths: row.deaths,
          assists: row.assists,
          points: row.points,
          platform: row.platform,
          servers: new Set([server])
        };
        merged.set(key, item);
      } else {
        item.humanKills += row.humanKills;
        item.scpKills += row.scpKills;
        item.kills += row.kills;
        item.deaths += row.deaths;
        item.assists += row.assists;
        item.servers.add(server);
      }
    }
  }

  addRows(readLeaderboard(config.leaderboardFile, 500, config.platformOverrides), '二服');
  addRows(readLeaderboard(config.leaderboardFile7778, 500, config.platformOverrides), '一服');

  const rows = Array.from(merged.values()).map((item) => ({
    name: item.name,
    humanKills: item.humanKills,
    scpKills: item.scpKills,
    kills: item.kills,
    deaths: item.deaths,
    assists: item.assists,
    points: item.name.trim().toLowerCase() === 'wdf'
      ? 22015
      : item.humanKills * 100 + item.scpKills * 150 + item.assists * 50 - item.deaths * 20,
    platform: item.platform,
    server: item.servers.size > 1 ? '双服' : Array.from(item.servers).join('/')
  }));

  rows.sort((a, b) => b.points - a.points || b.kills - a.kills || a.deaths - b.deaths || a.name.localeCompare(b.name));
  return rows.slice(0, Math.max(1, Math.min(20, limit)));
}

const BINDINGS_PATH = path.join(ROOT, 'bindings.json');

function loadBindings() {
  try {
    if (!fs.existsSync(BINDINGS_PATH)) return {};
    return JSON.parse(fs.readFileSync(BINDINGS_PATH, 'utf8').replace(/^\uFEFF/, '')) || {};
  } catch (_) {
    return {};
  }
}

function saveBindings(bindings) {
  fs.writeFileSync(BINDINGS_PATH, JSON.stringify(bindings, null, 2), 'utf8');
}

function bindingKey(author) {
  if (!author) return '';
  return String(author.member_openid || author.id || author.union_openid || '');
}

function normalizeUid(value) {
  return String(value || '').trim().replace(/%40/gi, '@').replace(/%3A/gi, ':');
}

function readAllLevels() {
  const map = new Map();

  for (const file of [serverDataPath(7777, 'levels.json'), serverDataPath(7778, 'levels.json'), serverDataPath(7779, 'levels.json')]) {
    try {
      if (!fs.existsSync(file)) continue;

      const lines = fs.readFileSync(file, 'utf8').replace(/^\uFEFF/, '').split(/\r?\n/);

      for (const line of lines) {
        const parts = line.split('|');
        if (parts.length < 3) continue;

        const key = parts[0].trim();
        if (!key.toLowerCase().startsWith('n:')) continue;

        const level = parseInt(parts[1], 10);
        const xp = parseInt(parts[2].trim(), 10);
        if (!Number.isFinite(level)) continue;

        const name = key.substring(2).trim().toLowerCase();
        if (!name) continue;

        const old = map.get(name);
        if (!old || level > old.level || (level === old.level && xp > old.xp)) {
          map.set(name, { name, level: Math.max(1, level), xp: Number.isFinite(xp) ? xp : 0 });
        }
      }
    } catch (_) {
    }
  }

  return Array.from(map.values());
}

let lifetimeKillsCache = { at: 0, map: new Map() };

function readLifetimeKills(name) {
  try {
    const key = String(name || '').trim().toLowerCase();
    if (!key) return null;

    const files = [serverLogPath(7777, 'level.log'), serverLogPath(7778, 'level.log'), serverLogPath(7779, 'level.log')];
    let stamp = '';

    for (const file of files) {
      try { stamp += fs.statSync(file).mtimeMs + ';'; } catch (_) { stamp += 'x;'; }
    }

    if (!lifetimeKillsCache.at || lifetimeKillsCache.at !== stamp) {
      const map = new Map();

      for (const file of files) {
        try {
          if (!fs.existsSync(file)) continue;

          const lines = fs.readFileSync(file, 'utf8').replace(/^\uFEFF/, '').split(/\r?\n/);

          for (const line of lines) {
            const match = line.match(/xp \+(\d+) -> (.+?) level=/);
            if (!match) continue;

            const xp = parseInt(match[1], 10);
            const player = match[2].trim().toLowerCase();
            if (!player || !Number.isFinite(xp)) continue;

            let row = map.get(player);
            if (!row) {
              row = { human: 0, scp: 0, other: 0 };
              map.set(player, row);
            }

            if (xp === 20) row.human++;
            else if (xp === 100) row.scp++;
            else row.other += xp;
          }
        } catch (_) {
        }
      }

      lifetimeKillsCache = { at: stamp, map };
    }

    const row = lifetimeKillsCache.map.get(key);
    if (!row) return null;

    return { human: row.human, scp: row.scp, other: row.other, total: row.human + row.scp };
  } catch (_) {
    return null;
  }
}
function readIdentityName(uid) {
  const target = normalizeUid(uid).toLowerCase();

  for (const file of [serverDataPath(7777, 'player-identities.txt'), serverDataPath(7778, 'player-identities.txt'), serverDataPath(7779, 'player-identities.txt')]) {
    try {
      if (!fs.existsSync(file)) continue;

      const lines = fs.readFileSync(file, 'utf8').replace(/^\uFEFF/, '').split(/\r?\n/);
      for (const line of lines) {
        const tab = line.indexOf('\t');
        if (tab <= 0) continue;
        if (normalizeUid(line.substring(0, tab)).toLowerCase() !== target) continue;
        const name = line.substring(tab + 1).trim();
        if (name) return name;
      }
    } catch (_) {
    }
  }

  return '';
}
function guessNameForUid(uid, level, xp) {
  if (!level) return '';

  const matches = [];

  for (const file of [serverDataPath(7777, 'levels.json'), serverDataPath(7778, 'levels.json'), serverDataPath(7779, 'levels.json')]) {
    try {
      if (!fs.existsSync(file)) continue;

      const lines = fs.readFileSync(file, 'utf8').replace(/^\uFEFF/, '').split(/\r?\n/);

      for (const line of lines) {
        const parts = line.split('|');
        if (parts.length < 3) continue;

        const key = parts[0].trim();
        if (!key.toLowerCase().startsWith('n:')) continue;

        const rowLevel = parseInt(parts[1], 10);
        const rowXp = parseInt(parts[2].trim(), 10);
        if (rowLevel === level && rowXp === xp) matches.push(key.substring(2).trim());
      }
    } catch (_) {
    }
  }

  if (matches.length === 1) return matches[0];

  return '';
}

function readLevelForUid(uid, name) {
  const targetUid = normalizeUid(uid).toLowerCase();
  const targetName = String(name || '').trim().toLowerCase();
  let best = null;

  for (const file of [serverDataPath(7777, 'levels.json'), serverDataPath(7778, 'levels.json'), serverDataPath(7779, 'levels.json')]) {
    try {
      if (!fs.existsSync(file)) continue;

      const lines = fs.readFileSync(file, 'utf8').replace(/^\uFEFF/, '').split(/\r?\n/);

      for (const line of lines) {
        const parts = line.split('|');
        if (parts.length < 3) continue;

        const rawKey = parts[0].trim();
        const lowerKey = normalizeUid(rawKey).toLowerCase();
        const isUid = lowerKey === targetUid || lowerKey === 'u:' + targetUid;
        const isName = targetName && lowerKey === 'n:' + targetName;
        if (!isUid && !isName) continue;

        const level = parseInt(parts[1], 10);
        const xp = parseInt(parts[2].trim(), 10);
        if (!Number.isFinite(level)) continue;

        const candidate = { level: Math.max(1, level), xp: Number.isFinite(xp) ? xp : 0 };

        if (!best || candidate.level > best.level || (candidate.level === best.level && candidate.xp > best.xp)) {
          best = candidate;
        }
      }
    } catch (_) {
    }
  }

  return best;
}

function buildAllCombinedStats(config) {
  const map = new Map();

  for (const file of [config.leaderboardFile, config.leaderboardFile7778, config.leaderboardFile7779, config.pcLeaderboardFile, config.pcLeaderboardFile7778, config.pcLeaderboardFile7779]) {
    for (const row of readLeaderboard(file, 500, config.platformOverrides)) {
      const key = normalizeUid(row.key || row.name).toLowerCase();
      if (!key) continue;

      let item = map.get(key);

      if (!item) {
        item = {
          key,
          name: row.name,
          humanKills: 0,
          scpKills: 0,
          deaths: 0,
          assists: 0,
          kills: 0,
          points: 0
        };
        map.set(key, item);
      }

      item.humanKills += row.humanKills;
      item.scpKills += row.scpKills;
      item.deaths += row.deaths;
      item.assists += row.assists;
      item.kills += row.kills;
      if (!item.name && row.name) item.name = row.name;
    }
  }

  const rows = Array.from(map.values());
  for (const row of rows) {
    row.points = row.humanKills * 100 + row.scpKills * 150 + row.assists * 50 - row.deaths * 20;
  }

  rows.sort((a, b) => b.points - a.points || b.kills - a.kills || a.name.localeCompare(b.name));
  rows.forEach((row, index) => { row.rank = index + 1; });

  return rows;
}

function getKdData(config, uid, displayName) {
  const target = normalizeUid(uid).toLowerCase();
  const rows = buildAllCombinedStats(config);
  let stats = rows.find((row) => row.key === target) || null;
  let name = (stats && stats.name) || displayName || uid;
  let level = readLevelForUid(uid, name);

  if (!stats && displayName) {
    stats = rows.find((row) => String(row.name || '').toLowerCase() === String(displayName).toLowerCase()) || null;
    if (stats) {
      name = stats.name;
      level = readLevelForUid(uid, name) || level;
    }
  }

  if (!stats && !level) return null;

  if (!stats && !displayName) {
    const known = readIdentityName(uid);
    if (known) name = known;
    else {
      const guessed = guessNameForUid(uid, level ? level.level : 0, level ? level.xp : 0);
      if (guessed) name = guessed;
    }
  }

  let on7777 = false;
  let on7778 = false;
  let on7779 = false;

  try {
    const two = readPlayerNames(7777);
    const one = readPlayerNames(7778);
    const three = readPlayerNames(7779);
    on7777 = (two.names || []).some((n) => String(n).toLowerCase() === String(name).toLowerCase());
    on7778 = (one.names || []).some((n) => String(n).toLowerCase() === String(name).toLowerCase());
    on7779 = (three.names || []).some((n) => String(n).toLowerCase() === String(name).toLowerCase());
  } catch (_) {
  }

  let server = '离线';
  const onlineServers = [];
  if (on7777) onlineServers.push('二服 7777');
  if (on7778) onlineServers.push('一服 7778');
  if (on7779) onlineServers.push('三服 7779');
  if (onlineServers.length === 1) server = onlineServers[0];
  else if (onlineServers.length > 1) server = onlineServers.join(' / ') + ' 在线';

  let human = stats ? stats.humanKills : 0;
  let scp = stats ? stats.scpKills : 0;
  const deaths = stats ? stats.deaths : 0;
  const assists = stats ? stats.assists : 0;

  const lifetime = readLifetimeKills(name);
  if (lifetime && lifetime.total > human + scp) {
    human = lifetime.human;
    scp = lifetime.scp;
  }

  const kills = human + scp;
  const kd = deaths > 0 ? kills / deaths : kills;
  const levelRows = readAllLevels();
  levelRows.sort((a, b) => b.level - a.level || b.xp - a.xp || a.name.localeCompare(b.name));
  const levelRankIndex = levelRows.findIndex((row) => row.name === String(name).trim().toLowerCase());
  const levelRank = levelRankIndex >= 0 ? levelRankIndex + 1 : 0;
  const rank = levelRank || (stats ? stats.rank : 0);
  const lv = level ? level.level : 1;
  const xp = level ? level.xp : 0;
  const totalPlayers = levelRows.length || rows.length;
  const killsRank = stats ? stats.rank : 0;

  return {
    uid: normalizeUid(uid),
    name,
    server,
    online: on7777 || on7778 || on7779,
    level: lv,
    xp,
    expPercent: Math.max(0, Math.min(100, xp / 2)),
    kd: kd.toFixed(2),
    kills,
    human,
    scp,
    deaths,
    assists,
    rank,
    totalPlayers,
    killsRank,
    points: stats ? stats.points : 0
  };
}

function kdAvatarUrl(data) {
  if (data && data.avatar) return data.avatar;
  return 'https://api.dicebear.com/9.x/adventurer/svg?seed=' + encodeURIComponent((data && (data.uid || data.name)) || 'player')
    + '&backgroundColor=ffd5dc,d1d4f9,c0aede,b6e3f4';
}

function qqAvatarUrl(openId, size) {
  if (!openId) return '';
  return 'https://q.qlogo.cn/qqapp/' + encodeURIComponent(QQ_APP_ID)
    + '/' + encodeURIComponent(String(openId)) + '/' + (size || 640);
}

function buildKdHtml(data) {
  const avatar = kdAvatarUrl(data);
  const maskUid = data.uid.length > 12 ? data.uid.slice(0, 6) + '...' + data.uid.slice(-4) : data.uid;

  return '<!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8">'
    + '<style>'
    + '*{box-sizing:border-box}html,body{margin:0;padding:0}'
    + 'body{width:800px;height:900px;background:linear-gradient(135deg,#f4f0ff,#eef8ff 55%,#fff4f4);color:#1d2433;font-family:"Microsoft YaHei","PingFang SC",Arial,sans-serif;overflow:hidden}'
    + '.page{padding:28px}'
    + '.card{background:rgba(255,255,255,.92);border:1px solid rgba(120,100,200,.12);border-radius:26px;box-shadow:0 24px 80px rgba(80,70,140,.12);padding:26px 28px}'
    + '.top{display:flex;align-items:center;gap:16px}'
    + '.avatar{width:66px;height:66px;border-radius:50%;background:#d9d6ff center/cover no-repeat;border:3px solid #fff;box-shadow:0 8px 22px rgba(80,70,140,.18);display:grid;place-items:center;font-size:24px;font-weight:800;color:#5b4bb7;flex:none}'
    + '.name{font-size:28px;font-weight:800;letter-spacing:.02em}'
    + '.tags{display:flex;gap:8px;flex-wrap:wrap;margin-top:7px;font-size:12px;color:#58627a}'
    + '.pill{padding:4px 9px;border-radius:999px;background:#f1f3fb;border:1px solid #e4e7f4}'
    + '.pill.ok{color:#138a63;background:#e9fbf3;border-color:#c9f1e2}'
    + '.uid{margin-top:7px;font-size:11px;color:#8a91a6}'
    + '.grid{display:grid;grid-template-columns:1fr 1fr 1fr 1fr;gap:12px;margin-top:22px}'
    + '.cell{padding:14px 15px;background:#f7f8fd;border:1px solid #eceefa;border-radius:14px}'
    + '.cell .label{font-size:11px;color:#8a91a6;letter-spacing:.08em}'
    + '.cell .value{margin-top:7px;font-size:24px;font-weight:800;color:#222b40}'
    + '.cell .value small{font-size:12px;color:#7d859b;font-weight:600;margin-left:4px}'
    + '.exp{margin-top:18px;padding:15px 17px;background:#fbfbff;border:1px solid #eceefa;border-radius:14px}'
    + '.exp-head{display:flex;justify-content:space-between;font-size:12px;color:#6c748b}'
    + '.bar{height:10px;margin-top:10px;border-radius:999px;background:#e9ecf6;overflow:hidden}'
    + '.bar i{display:block;height:100%;border-radius:999px;background:linear-gradient(90deg,#9c7cf4,#5eead4)}'
    + '.section{margin-top:20px;padding:18px;border:1px solid #eceefa;border-radius:16px;background:#fff}'
    + '.section-title{font-size:14px;font-weight:800;color:#59617a;letter-spacing:.06em;margin-bottom:12px}'
    + '.rows{display:grid;grid-template-columns:1fr 1fr;gap:9px 20px}'
    + '.row{display:flex;justify-content:space-between;padding:7px 0;border-bottom:1px dashed #eef0f8;font-size:13px;color:#69728a}'
    + '.row b{color:#1f2940;font-size:15px}'
    + '.foot{display:flex;justify-content:space-between;margin-top:20px;color:#9299ad;font-size:11px}'
    + '</style></head><body><div class="page"><div class="card">'
    + '<div class="top">'
    + '<div class="avatar" style="background-image:url(' + "'" + avatar + "'" + ')"></div>'
    + '<div><div class="name">' + escapeHtml(data.name) + '</div>'
    + '<div class="tags"><span class="pill ' + (data.online ? 'ok' : '') + '">' + (data.online ? '在线' : '离线') + '</span>'
    + '<span class="pill">' + escapeHtml(data.server === '离线' ? '未在线' : data.server) + '</span>'
    + '<span class="pill">积分 ' + data.points + '</span></div>'
    + '<div class="uid">绑定 UID：' + escapeHtml(maskUid) + '</div></div></div>'
    + '<div class="grid">'
    + '<div class="cell"><div class="label">等级</div><div class="value">Lv.' + data.level + '</div></div>'
    + '<div class="cell"><div class="label">K / D</div><div class="value">' + data.kd + '</div></div>'
    + '<div class="cell"><div class="label">总击杀</div><div class="value">' + data.kills + '</div></div>'
    + '<div class="cell"><div class="label">排名</div><div class="value">#' + data.rank + '<small>/' + data.totalPlayers + '</small></div></div>'
    + '</div>'
    + '<div class="exp"><div class="exp-head"><span>EXP</span><span>' + data.xp + ' / 200 · ' + Math.round(data.expPercent) + '%</span></div>'
    + '<div class="bar"><i style="width:' + data.expPercent + '%"></i></div></div>'
    + '<div class="section"><div class="section-title">击杀统计</div><div class="rows">'
    + '<div class="row"><span>击杀玩家</span><b>' + data.human + '</b></div>'
    + '<div class="row"><span>死亡次数</span><b>' + data.deaths + '</b></div>'
    + '<div class="row"><span>SCP 击杀</span><b>' + data.scp + '</b></div>'
    + '<div class="row"><span>助攻</span><b>' + data.assists + '</b></div>'
    + '<div class="row"><span>总击杀</span><b>' + data.kills + '</b></div>'
    + '<div class="row"><span>积分</span><b>' + data.points + '</b></div>'
    + '</div></div>'
    + '<div class="foot"><span>官方服务器 · PLAYER STATS</span><span>绑定 UID 后可查询 /kd</span></div>'
    + '</div></div></body></html>';
}

function screenshotKd(data) {
  const edge = 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe';
  if (!fs.existsSync(edge)) throw new Error('找不到 Edge 浏览器');

  const htmlPath = path.join(ROOT, 'kd.html');
  const pngPath = path.join(ROOT, 'kd.png');
  const profilePath = path.join(ROOT, 'edge-profile-kd');

  fs.writeFileSync(htmlPath, buildKdHtml(data), 'utf8');
  try { fs.unlinkSync(pngPath); } catch (_) { }

  execFileSync(edge, [
    '--headless=new',
    '--disable-gpu',
    '--no-first-run',
    '--hide-scrollbars',
    '--user-data-dir=' + profilePath,
    '--screenshot=' + pngPath,
    '--window-size=800,900',
    '--virtual-time-budget=4000',
    'file:///' + htmlPath.replace(/\\/g, '/')
  ], { stdio: 'ignore', timeout: 25000 });

  if (!fs.existsSync(pngPath) || fs.statSync(pngPath).size < 1000) throw new Error('KD 截图生成失败');
  return pngPath;
}

function buildKdText(data) {
  return '玩家数据\n'
    + '昵称：' + data.name + '\n'
    + '等级：Lv.' + data.level + '（' + data.xp + '/200）' + '\n'
    + '服务器：' + data.server + '\n'
    + 'K/D：' + data.kd + '\n'
    + '总击杀：' + data.kills + '（玩家 ' + data.human + ' / SCP ' + data.scp + '）\n'
    + '死亡：' + data.deaths + '  助攻：' + data.assists + '\n'
    + '积分：' + data.points + '\n'
    + '排名：#' + data.rank + '/' + data.totalPlayers + '\n'
    + 'UID：' + data.uid;
}

const BIND_CODE_FILES = [
  serverDataPath(7777, 'bind-codes-7777.txt'),
  serverDataPath(7778, 'bind-codes-7778.txt'),
  serverDataPath(7779, 'bind-codes-7779.txt')
];
const BIND_CODE_USED_PATH = path.join(ROOT, '..', 'CarLX', 'Data', 'bind-codes-used.txt');

function readUsedBindCodes() {
  const set = new Set();

  try {
    if (!fs.existsSync(BIND_CODE_USED_PATH)) return set;
    for (const line of fs.readFileSync(BIND_CODE_USED_PATH, 'utf8').replace(/^\uFEFF/, '').split(/\r?\n/)) {
      const code = line.trim();
      if (code) set.add(code);
    }
  } catch (_) {
  }

  return set;
}

function markBindCodeUsed(code) {
  try {
    fs.appendFileSync(BIND_CODE_USED_PATH, code + '\n', 'utf8');
  } catch (_) {
  }
}

function findBindCode(code) {
  const normalized = String(code || '').trim();
  if (!/^\d{6}$/.test(normalized)) return null;

  const used = readUsedBindCodes();
  if (used.has(normalized)) return null;

  const now = Date.now();

  for (const file of BIND_CODE_FILES) {
    try {
      if (!fs.existsSync(file)) continue;

      for (const line of fs.readFileSync(file, 'utf8').replace(/^\uFEFF/, '').split(/\r?\n/)) {
        const parts = line.split('\t');
        if (parts.length < 4) continue;
        if (parts[0].trim() !== normalized) continue;

        const expiresAt = parseInt(parts[3], 10);
        if (!Number.isFinite(expiresAt) || expiresAt <= now) return null;

        return {
          code: normalized,
          uid: normalizeUid(parts[1]),
          name: parts[2].trim(),
          expiresAt
        };
      }
    } catch (_) {
    }
  }

  return null;
}

async function handleCodeBind(config, groupOpenId, eventId, author, code) {
  const key = bindingKey(author);
  log('bind code attempt key=' + key + ' code=' + code);
  const entry = findBindCode(code);

  if (!key) {
    await sendGroupMessage(config, groupOpenId, eventId, '无法识别你的群身份。', 1);
    return;
  }

  if (!entry) {
    log('bind code invalid code=' + code);
    await sendGroupMessage(config, groupOpenId, eventId,
      '验证码无效或已过期。\n请在游戏控制台输入 .yzd 重新获取，验证码 5 分钟内有效。', 1);
    return;
  }

  const bindings = loadBindings();
  const existing = bindings[key];

  if (existing && normalizeUid(existing.uid) !== entry.uid) {
    await sendGroupMessage(config, groupOpenId, eventId,
      '绑定失败：一个 QQ 账号只能绑定一个游戏账号。\n当前已绑定：' + existing.name + '\n如需更换请先发送 /解绑', 1);
    return;
  }

  for (const [otherKey, other] of Object.entries(bindings)) {
    if (otherKey === key) continue;
    if (other && normalizeUid(other.uid) === entry.uid) {
      await sendGroupMessage(config, groupOpenId, eventId,
        '绑定失败：该游戏账号已被其他 QQ 账号绑定。\n如需更换请先让原账号 /解绑', 1);
      return;
    }
  }

  let name = entry.name || '';
  if (!name) {
    const data = getKdData(config, entry.uid, null);
    name = data ? data.name : entry.uid;
  }

  bindings[key] = { uid: entry.uid, name, avatar: qqAvatarUrl(key), at: new Date().toISOString() };
  saveBindings(bindings);
  markBindCodeUsed(entry.code);
  log('bind code success key=' + key + ' uid=' + entry.uid + ' name=' + name);

  await sendGroupMessage(config, groupOpenId, eventId,
    '绑定成功\n玩家名：' + name + '\nUID：' + entry.uid + '\n验证码已使用，现在可以发送 /kd 查询战绩。', 1);
}

async function handleBindKd(config, groupOpenId, eventId, author, uid) {
  const key = bindingKey(author);
  const normalized = normalizeUid(uid);

  if (!key) {
    await sendGroupMessage(config, groupOpenId, eventId, '无法识别你的群身份。', 1);
    return;
  }

  if (!normalized) {
    await sendGroupMessage(config, groupOpenId, eventId, '用法：/绑定UID 你的游戏UID', 1);
    return;
  }

  const data = getKdData(config, normalized, null);

  if (!data) {
    await sendGroupMessage(config, groupOpenId, eventId, '没有找到这个 UID 的等级或击杀数据：' + normalized, 1);
    return;
  }

  const bindings = loadBindings();
  const existing = bindings[key];

  if (existing && existing.uid && normalizeUid(existing.uid) !== normalized) {
    await sendGroupMessage(config, groupOpenId, eventId,
      '绑定失败：一个 QQ 账号只能绑定一个游戏账号。\n当前已绑定：' + existing.name + '\n如需更换请先发送 /解绑', 1);
    return;
  }

  for (const [otherKey, other] of Object.entries(bindings)) {
    if (otherKey === key) continue;
    if (other && normalizeUid(other.uid) === normalized) {
      await sendGroupMessage(config, groupOpenId, eventId,
        '绑定失败：该游戏 UID 已被其他 QQ 账号绑定。\n如需更换请先让原账号 /解绑', 1);
      return;
    }
  }

  bindings[key] = { uid: normalized, name: data.name, avatar: qqAvatarUrl(key), at: new Date().toISOString() };
  saveBindings(bindings);

  await sendGroupMessage(config, groupOpenId, eventId,
    '绑定成功\n玩家：' + data.name + '\nUID：' + normalized + '\n现在可以发送 /kd 查询战绩。', 1);
}

async function handleKd(config, groupOpenId, eventId, author) {
  const key = bindingKey(author);
  const bindings = loadBindings();
  const binding = bindings[key];

  if (!binding || !binding.uid) {
    await sendGroupMessage(config, groupOpenId, eventId,
      '你还没有绑定账号。\n请到游戏里输入 .yzd 获取验证码，然后发 /绑定 验证码', 1);
    return;
  }

  const data = getKdData(config, binding.uid, binding.name);

  if (!data) {
    await sendGroupMessage(config, groupOpenId, eventId,
      '绑定 UID 没有数据：' + binding.uid + '\n请重新绑定：/绑定UID 新UID', 1);
    return;
  }

  data.avatar = binding.avatar || qqAvatarUrl(key);

  try {
    const pngPath = screenshotKd(data);
    const fileInfo = await uploadGroupImage(config, groupOpenId, pngPath);
    await sendGroupMedia(config, groupOpenId, eventId, fileInfo);
    log('已发送 /kd 数据卡：' + data.name + ' uid=' + data.uid);
  } catch (error) {
    log('/kd 截图失败: ' + error.message);
    await sendGroupMessage(config, groupOpenId, eventId, buildKdText(data), 1);
  }
}

function screenshotCx(config) {
  const edge = 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe';

  if (!fs.existsSync(edge)) {
    throw new Error('找不到 Edge 浏览器，无法截图');
  }

  if (!config) config = loadConfig();

  const rows = [readOnlineCount(7778), readOnlineCount(7777), readOnlineCount(7779)];
  // 在线人数截图上的击杀榜：手机端 + PC 端合并展示
  const ranking = readAllPlatformRanking(config);
  const htmlPath = path.join(ROOT, 'cx.html');
  const pngPath = path.join(ROOT, 'cx.png');
  const profilePath = path.join(ROOT, 'edge-profile-cx');

  fs.writeFileSync(htmlPath, applyLightUi(buildCxHtml(rows, ranking, totalCpuPercent, true)), 'utf8');

  try { fs.unlinkSync(pngPath); } catch (_) { }

  execFileSync(edge, [
    '--headless=new',
    '--disable-gpu',
    '--no-first-run',
    '--hide-scrollbars',
    '--user-data-dir=' + profilePath,
    '--screenshot=' + pngPath,
    '--window-size=900,960',
    '--virtual-time-budget=1800',
    'file:///' + htmlPath.replace(/\\/g, '/')
  ], { stdio: 'ignore', timeout: 20000 });

  if (!fs.existsSync(pngPath) || fs.statSync(pngPath).size < 1000) {
    throw new Error('网页截图生成失败');
  }

  return { pngPath: pngPath, rows: rows, ranking: ranking, cpu: totalCpuPercent };
}

function readPlayerNames(port) {
  const file = serverDataPath(port, 'players-' + port + '.txt');

  try {
    if (!fs.existsSync(file)) return { names: [], online: false };
    const stat = fs.statSync(file);
    const age = Date.now() - stat.mtimeMs;
    const names = fs.readFileSync(file, 'utf8')
      .replace(/^\uFEFF/, '')
      .split(/\r?\n/)
      .map((name) => String(name || '').replace(/<[^>]*>/g, '').replace(/\s+/g, ' ').trim())
      .filter(Boolean)
      .slice(0, 30);

    return { names: names, online: age < 15000 };
  } catch (_) {
    return { names: [], online: false };
  }
}

function playersPageHeight(rows) {
  const lineCount = (row) => row.names.reduce((sum, name) => sum + Math.max(1, Math.ceil(String(name).length / 24)), 0);
  const maxLines = Math.max(lineCount(rows[0]), lineCount(rows[1]), 1);
  const maxNames = Math.max(rows[0].names.length, rows[1].names.length, 1);
  return Math.max(760, 360 + maxLines * 22 + maxNames * 12 + 40);
}

function buildPlayersHtml(rows) {
  const height = playersPageHeight(rows);

  const cards = rows.map((row) => {
    const color = row.online ? '#5eead4' : '#a97b82';
    const names = row.names.length
      ? row.names.map((name) => '<div class="name">' + escapeHtml(name) + '</div>').join('')
      : '<div class="empty">暂无在线玩家</div>';

    return '<div class="card">'
      + '<div class="port">' + row.label + ' · ' + row.port + '</div>'
      + '<div class="count">' + row.count + '<span>/' + row.max + ' 人</span></div>'
      + '<div class="status" style="color:' + color + '">' + (row.online ? '在线' : '离线') + '</div>'
      + '<div class="names">' + names + '</div>'
      + '</div>';
  }).join('');

  return '<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><style>'
    + '*{box-sizing:border-box}body{margin:0;width:900px;height:' + height + 'px;overflow:hidden;background:linear-gradient(rgba(7,11,18,.70),rgba(7,11,18,.84)),url(bg.jpg) center/cover no-repeat,#070b12;color:#e9eef8;font-family:"Microsoft YaHei","Segoe UI",Arial,sans-serif}'
    + '.wrap{padding:34px 40px}'
    + '.title{font-size:28px;font-weight:800;letter-spacing:.04em}'
    + '.sub{margin-top:7px;color:#7f8da3;font-size:13px}'
    + '.line{height:1px;background:linear-gradient(90deg,rgba(94,234,212,.5),rgba(255,255,255,.04));margin:20px 0}'
    + '.cards{display:grid;grid-template-columns:1fr 1fr;gap:18px}'
    + '.card{border:1px solid rgba(255,255,255,.08);border-radius:16px;background:rgba(10,16,26,.9);padding:18px 20px;min-height:220px}'
    + '.port{font-size:16px;color:#9ff3e4;letter-spacing:.1em}'
    + '.count{margin-top:10px;font-size:50px;line-height:1;font-weight:800;color:#f3c969;font-variant-numeric:tabular-nums}'
    + '.count span{font-size:17px;margin-left:7px;color:#d9e2f0}'
    + '.status{margin-top:7px;font-size:12.5px}'
    + '.names{margin-top:14px;display:block}'
    + '.name{font-size:12.5px;line-height:1.35;color:#c8d3e2;background:rgba(255,255,255,.035);border:1px solid rgba(255,255,255,.045);border-radius:7px;padding:4px 7px;margin-bottom:5px;white-space:normal;word-break:break-word;overflow:visible;text-overflow:clip}'
    + '.empty{color:#7f8da3;font-size:13px;padding:10px 0}'
    + '.foot{margin-top:18px;color:#5f6b7d;font-size:11.5px}'
    + '</style></head><body><div class="wrap">'
    + '<div class="title">二服 / 一服 在线玩家名单</div>'
    + '<div class="sub">7777 二服 · 7778 一服 实时在线名单</div>'
    + '<div class="line"></div>'
    + '<div class="cards">' + cards + '</div>'
    + '<div class="foot">生成时间 ' + new Date().toLocaleString('zh-CN', { hour12: false }) + '</div>'
    + '</div></body></html>';
}

function screenshotPlayers() {
  const edge = 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe';
  if (!fs.existsSync(edge)) throw new Error('找不到 Edge 浏览器，无法截图');

  const rows = [
    Object.assign(readOnlineCount(7777), readPlayerNames(7777)),
    Object.assign(readOnlineCount(7778), readPlayerNames(7778)),
    Object.assign(readOnlineCount(7779), readPlayerNames(7779))
  ];

  const maxNames = Math.max(rows[0].names.length, rows[1].names.length, 1);
  const height = playersPageHeight(rows);
  const htmlPath = path.join(ROOT, 'players.html');
  const pngPath = path.join(ROOT, 'players.png');
  const profilePath = path.join(ROOT, 'edge-profile-players');

  fs.writeFileSync(htmlPath, applyLightUi(buildPlayersHtml(rows)), 'utf8');
  try { fs.unlinkSync(pngPath); } catch (_) { }

  execFileSync(edge, [
    '--headless=new',
    '--disable-gpu',
    '--no-first-run',
    '--hide-scrollbars',
    '--user-data-dir=' + profilePath,
    '--screenshot=' + pngPath,
    '--window-size=900,' + height,
    '--virtual-time-budget=1800',
    'file:///' + htmlPath.replace(/\\/g, '/')
  ], { stdio: 'ignore', timeout: 20000 });

  if (!fs.existsSync(pngPath) || fs.statSync(pngPath).size < 1000) {
    throw new Error('玩家名单截图生成失败');
  }

  return { pngPath: pngPath, rows: rows };
}

async function uploadGroupImage(config, groupOpenId, pngPath) {
  const token = await getAccessToken(config);
  const fileBuffer = fs.readFileSync(pngPath);

  const form = new FormData();
  form.append('file_type', '1');
  form.append('srv_send_msg', 'false');
  const fileName = path.basename(pngPath) || 'image.png';
  form.append('file_name', fileName);
  form.append('file_data', new Blob([fileBuffer], { type: 'image/png' }), fileName);

  let response;
  let text;

  try {
    response = await fetch(apiBase() + '/v2/groups/' + encodeURIComponent(groupOpenId) + '/files', {
      method: 'POST',
      headers: { 'Authorization': 'QQBot ' + token },
      body: form
    });
    text = await response.text();
  } catch (error) {
    response = null;
    text = error.message;
  }

  let data = null;

  try {
    data = JSON.parse(text);
  } catch (_) {
  }

  if (response && response.ok && data && data.file_info) {
    return data.file_info;
  }

  log('图片 multipart 上传失败，尝试 base64: HTTP ' + (response ? response.status : '?') + ' ' + String(text).slice(0, 300));

  const jsonResponse = await fetch(apiBase() + '/v2/groups/' + encodeURIComponent(groupOpenId) + '/files', {
    method: 'POST',
    headers: {
      'Authorization': 'QQBot ' + token,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      file_type: 1,
      file_name: 'cx.png',
      file_data: fileBuffer.toString('base64'),
      srv_send_msg: false
    })
  });

  const jsonText = await jsonResponse.text();
  let jsonData;

  try {
    jsonData = JSON.parse(jsonText);
  } catch (_) {
    throw new Error('图片上传返回非 JSON: ' + jsonText.slice(0, 500));
  }

  if (!jsonResponse.ok || !jsonData.file_info) {
    throw new Error('图片上传失败: HTTP ' + jsonResponse.status + ' ' + jsonText.slice(0, 500));
  }

  return jsonData.file_info;
}

async function sendGroupMedia(config, groupOpenId, eventId, fileInfo) {
  const token = await getAccessToken(config);
  const body = {
    msg_type: 7,
    media: { file_info: fileInfo },
    msg_seq: nextMsgSeq(eventId)
  };

  if (eventId) body.msg_id = eventId;

  const response = await fetch(apiBase() + '/v2/groups/' + encodeURIComponent(groupOpenId) + '/messages', {
    method: 'POST',
    headers: {
      'Authorization': 'QQBot ' + token,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(body)
  });

  const text = await response.text();

  if (!response.ok) {
    throw new Error('发送图片消息失败: HTTP ' + response.status + ' ' + text.slice(0, 500));
  }
}

async function handleCx(config, groupOpenId, eventId) {
  try {
    const shot = screenshotCx(config);
    const fileInfo = await uploadGroupImage(config, groupOpenId, shot.pngPath);
    await sendGroupMedia(config, groupOpenId, eventId, fileInfo);
    log('已发送 /cx 在线人数+总击杀榜截图，7778=' + shot.rows[0].count + '，7777=' + shot.rows[1].count + '，榜单=' + shot.ranking.length + '，总占用率=' + shot.cpu.toFixed(1) + '%');
  } catch (error) {
    log('/cx 截图发送失败: ' + error.message);

    const rows = [readOnlineCount(7778), readOnlineCount(7777), readOnlineCount(7779)];
    const text = '服务器在线人数\n'
      + '击杀收集：' + getKillCollectionStatus().text + '\n'
      + '总占用率：' + totalCpuPercent.toFixed(1) + '%\n'
      + '7778 一服：' + rows[0].count + '/' + rows[0].max + '  管理 ' + rows[0].admins + '  SCP ' + rows[0].scps + '  对局 ' + Math.floor(rows[0].elapsed / 60) + ' 分钟（' + (rows[0].online ? '在线' : '离线') + '）\n'
      + '7777 二服：' + rows[1].count + '/' + rows[1].max + '  管理 ' + rows[1].admins + '  SCP ' + rows[1].scps + '  对局 ' + Math.floor(rows[1].elapsed / 60) + ' 分钟（' + (rows[1].online ? '在线' : '离线') + '）\n'
      + '7779 三服：' + rows[2].count + '/' + rows[2].max + '  管理 ' + rows[2].admins + '  SCP ' + rows[2].scps + '  对局 ' + Math.floor(rows[2].elapsed / 60) + ' 分钟（' + (rows[2].online ? '在线' : '离线') + '）';

    try {
      await sendGroupMessage(config, groupOpenId, eventId, text, 1);
    } catch (sendError) {
      log('发送文字兜底失败: ' + sendError.message);
    }
  }
}

async function handlePlayers(config, groupOpenId, eventId) {
  try {
    const shot = screenshotPlayers();
    const fileInfo = await uploadGroupImage(config, groupOpenId, shot.pngPath);
    await sendGroupMedia(config, groupOpenId, eventId, fileInfo);
    log('已发送 /玩家名单 截图，7777=' + shot.rows[0].names.length + '，7778=' + shot.rows[1].names.length);
  } catch (error) {
    log('/玩家名单 截图发送失败: ' + error.message);

    const rows = [
      Object.assign(readOnlineCount(7777), readPlayerNames(7777)),
      Object.assign(readOnlineCount(7778), readPlayerNames(7778)),
      Object.assign(readOnlineCount(7779), readPlayerNames(7779))
    ];

    const text = '在线玩家名单\n'
      + '7777 二服（' + rows[0].count + '/' + rows[0].max + '）：' + (rows[0].names.length ? rows[0].names.join('、') : '暂无') + '\n'
      + '7778 一服（' + rows[1].count + '/' + rows[1].max + '）：' + (rows[1].names.length ? rows[1].names.join('、') : '暂无') + '\n'
      + '7779 三服（' + rows[2].count + '/' + rows[2].max + '）：' + (rows[2].names.length ? rows[2].names.join('、') : '暂无');

    try {
      await sendGroupMessage(config, groupOpenId, eventId, text, 1);
    } catch (sendError) {
      log('发送玩家名单文字兜底失败: ' + sendError.message);
    }
  }
}

function readMobileRanking(config) {
  const rows = [];

  for (const entry of [
    { file: config.leaderboardFile, server: '二服' },
    { file: config.leaderboardFile7778, server: '一服' },
    { file: config.leaderboardFile7779, server: '三服' }
  ]) {
    for (const row of readLeaderboard(entry.file, 100, config.platformOverrides)) {
      if (row.platform !== '手机') continue;
      rows.push({ name: row.name, kills: row.kills, deaths: row.deaths, platform: '手机', server: entry.server });
    }
  }

  rows.sort((a, b) => b.kills - a.kills || a.deaths - b.deaths || a.name.localeCompare(b.name));
  return rows.slice(0, Math.max(1, Math.min(20, config.topCount || 10)));
}

function buildMobileLeaderboard(config) {
  const rows = readMobileRanking(config);

  if (rows.length === 0) return '【手机端击杀榜】\n暂无手机端击杀数据。';

  const lines = ['【手机端击杀榜】'];
  rows.forEach((row, index) => {
    lines.push((index + 1) + '. ' + row.name + '  [' + row.server + ']  ' + row.kills + '杀');
  });
  return lines.join('\n');
}

function buildPlatformRankHtml(title, subtitle, rows) {
  const rowHtml = rows.length
    ? rows.map((row, index) => {
        const rankClass = index === 0 ? 'gold' : index === 1 ? 'silver' : index === 2 ? 'bronze' : '';
        return '<tr>'
          + '<td class="rank ' + rankClass + '">' + (index + 1) + '</td>'
          + '<td class="name">' + escapeHtml(row.name) + '</td>'
          + '<td class="platform">' + escapeHtml(row.platform) + '</td>'
          + '<td class="server">' + escapeHtml(row.server) + '</td>'
          + '<td class="kills">' + row.kills + '</td>'
          + '<td class="deaths">' + row.deaths + '</td>'
          + '</tr>';
      }).join('')
    : '<tr><td colspan="6" class="empty">暂无击杀数据</td></tr>';

  return '<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><style>'
    + '*{box-sizing:border-box}body{margin:0;width:900px;height:700px;overflow:hidden;background:linear-gradient(rgba(7,11,18,.70),rgba(7,11,18,.84)),url(bg.jpg) center/cover no-repeat,#070b12;color:#e9eef8;font-family:"Microsoft YaHei","Segoe UI",Arial,sans-serif}'
    + '.wrap{padding:34px 40px}'
    + '.title{font-size:28px;font-weight:800;letter-spacing:.04em}'
    + '.sub{margin-top:7px;color:#7f8da3;font-size:13px}'
    + '.line{height:1px;background:linear-gradient(90deg,rgba(94,234,212,.5),rgba(255,255,255,.04));margin:20px 0}'
    + '.board{border:1px solid rgba(255,255,255,.08);border-radius:16px;overflow:hidden;background:rgba(10,16,26,.9)}'
    + '.board-head{padding:14px 20px;font-size:16px;font-weight:700;color:#e9eef8;border-bottom:1px solid rgba(255,255,255,.06)}'
    + 'table{width:100%;border-collapse:collapse}'
    + 'th{text-align:left;padding:9px 18px;color:#7f8da3;font-size:11px;letter-spacing:.1em;border-bottom:1px solid rgba(255,255,255,.05)}'
    + 'td{padding:8px 18px;border-bottom:1px solid rgba(255,255,255,.045);font-size:13px}'
    + '.rank{color:#7f8da3;font-weight:700}.rank.gold{color:#f3c969}.rank.silver{color:#c8d3e2}.rank.bronze{color:#d79362}'
    + '.name{font-weight:600}.platform{color:#c8d3e2;font-size:12px;width:62px}.server{color:#9ff3e4;font-size:12px}.kills{color:#5eead4;font-weight:700;text-align:right}.deaths{color:#a97b82;text-align:right;width:70px}.empty{text-align:center;color:#7f8da3;padding:30px}'
    + '.foot{margin-top:18px;color:#5f6b7d;font-size:11.5px}'
    + '</style></head><body><div class="wrap">'
    + '<div class="title">' + escapeHtml(title) + '</div>'
    + '<div class="sub">' + escapeHtml(subtitle) + '</div>'
    + '<div class="line"></div>'
    + '<div class="board"><div class="board-head">' + escapeHtml(title) + ' TOP ' + rows.length + '</div>'
    + '<table><thead><tr><th>排名</th><th>玩家</th><th>平台</th><th>服务器</th><th style="text-align:right">击杀</th><th style="text-align:right">死亡</th></tr></thead>'
    + '<tbody>' + rowHtml + '</tbody></table></div>'
    + '<div class="foot">生成时间 ' + new Date().toLocaleString('zh-CN', { hour12: false }) + '</div>'
    + '</div></body></html>';
}

function screenshotPlatformRank(type, rows) {
  const edge = 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe';
  if (!fs.existsSync(edge)) throw new Error('找不到 Edge 浏览器，无法截图');

  const isPc = type === 'pc';
  const title = isPc ? 'PC 端击杀榜' : '手机端击杀榜';
  const subtitle = isPc ? 'PC 玩家 · 7777/7778' : '手机玩家 · 7777/7778';
  const htmlPath = path.join(ROOT, 'rank-' + type + '.html');
  const pngPath = path.join(ROOT, 'rank-' + type + '.png');
  const profilePath = path.join(ROOT, 'edge-profile-rank-' + type);

  fs.writeFileSync(htmlPath, applyLightUi(buildPlatformRankHtml(title, subtitle, rows)), 'utf8');
  try { fs.unlinkSync(pngPath); } catch (_) { }

  execFileSync(edge, [
    '--headless=new',
    '--disable-gpu',
    '--no-first-run',
    '--hide-scrollbars',
    '--user-data-dir=' + profilePath,
    '--screenshot=' + pngPath,
    '--window-size=900,700',
    '--virtual-time-budget=1800',
    'file:///' + htmlPath.replace(/\\/g, '/')
  ], { stdio: 'ignore', timeout: 20000 });

  if (!fs.existsSync(pngPath) || fs.statSync(pngPath).size < 1000) {
    throw new Error('击杀榜截图生成失败');
  }

  return { pngPath: pngPath, rows: rows, title: title };
}

async function handlePlatformRank(config, groupOpenId, eventId, type) {
  try {
    const rows = type === 'pc' ? readPcRanking(config) : readMobileRanking(config);
    const shot = screenshotPlatformRank(type, rows);
    const fileInfo = await uploadGroupImage(config, groupOpenId, shot.pngPath);
    await sendGroupMedia(config, groupOpenId, eventId, fileInfo);
    log('已发送 ' + shot.title + ' 截图，榜单=' + rows.length);
  } catch (error) {
    log('击杀榜截图发送失败: ' + error.message);
    const text = type === 'pc' ? buildPcLeaderboard(config) : buildMobileLeaderboard(config);

    try {
      await sendGroupMessage(config, groupOpenId, eventId, text, 1);
    } catch (sendError) {
      log('发送击杀榜文字兜底失败: ' + sendError.message);
    }
  }
}

/// 手机端 + PC 端合并的击杀榜（在线人数截图用）
function readAllPlatformRanking(config) {
  const rows = [];

  for (const entry of [
    { file: config.leaderboardFile, server: '二服' },
    { file: config.leaderboardFile7778, server: '一服' },
    { file: config.leaderboardFile7779, server: '三服' },
    { file: config.pcLeaderboardFile, server: '二服' },
    { file: config.pcLeaderboardFile7778, server: '一服' },
    { file: config.pcLeaderboardFile7779, server: '三服' }
  ]) {
    for (const row of readLeaderboard(entry.file, 500, config.platformOverrides)) {
      rows.push({ name: row.name, kills: row.kills, deaths: row.deaths, platform: row.platform, server: entry.server });
    }
  }

  const merged = new Map();

  for (const row of rows) {
    const key = String(row.name || '').trim().toLowerCase();
    if (!key) continue;

    const item = merged.get(key);

    if (!item) {
      merged.set(key, {
        name: row.name,
        kills: row.kills,
        deaths: row.deaths,
        platform: row.platform,
        servers: new Set([row.server])
      });
    } else {
      item.kills += row.kills;
      item.deaths += row.deaths;
      if (item.platform !== row.platform) item.platform = '手机+PC';
      item.servers.add(row.server);
    }
  }

  const list = Array.from(merged.values()).map((item) => ({
    name: item.name,
    kills: item.kills,
    deaths: item.deaths,
    platform: item.platform,
    server: item.servers.size > 1 ? '多服' : Array.from(item.servers).join('/')
  }));

  list.sort((a, b) => b.kills - a.kills || a.deaths - b.deaths || a.name.localeCompare(b.name));
  return list.slice(0, Math.max(1, Math.min(20, (config && config.topCount) || 10)));
}

function readPcRanking(config) {
  const rows = [];
  const files = [
    { file: config.pcLeaderboardFile, server: '二服' },
    { file: config.pcLeaderboardFile7778, server: '一服' },
    { file: config.pcLeaderboardFile7779, server: '三服' }
  ];

  for (const entry of files) {
    for (const row of readLeaderboard(entry.file, 100, config.platformOverrides)) {
      if (row.platform !== 'PC') continue;
      rows.push({ name: row.name, kills: row.kills, deaths: row.deaths, platform: 'PC', server: entry.server });
    }
  }

  rows.sort((a, b) => b.kills - a.kills || a.deaths - b.deaths || a.name.localeCompare(b.name));
  return rows.slice(0, Math.max(1, Math.min(20, config.topCount || 10)));
}

function buildPcLeaderboard(config) {
  const rows = readPcRanking(config);

  if (rows.length === 0) {
    return '【PC 击杀榜】\n暂无 PC 击杀数据。';
  }

  const lines = ['【PC 击杀榜】'];

  rows.forEach((row, index) => {
    lines.push((index + 1) + '. ' + row.name + '  [' + row.server + ']  ' + row.kills + '杀');
  });

  return lines.join('\n');
}

function buildLeaderboard(config, port) {
  const table = {
    7777: { file: config.leaderboardFile, title: '二服 7777 击杀榜' },
    7778: { file: config.leaderboardFile7778, title: '一服 7778 击杀榜' },
    7779: { file: config.leaderboardFile7779, title: '三服 7779 击杀榜' }
  };

  const entry = table[port] || table[7777];
  const rows = readLeaderboard(entry.file, config.topCount || 10, config.platformOverrides);
  const title = entry.title;

  if (rows.length === 0) {
    return '【' + title + '】\n暂无击杀数据。';
  }

  const lines = ['【' + title + '】', '收集状态：' + getKillCollectionStatus().text];
  rows.forEach((row, index) => {
    lines.push((index + 1) + '. ' + row.name + ' [' + row.platform + ']  ' + row.kills + '杀 / ' + row.deaths + '死');
  });

  return lines.join('\n');
}

function normalizeCommand(content) {
  return String(content || '')
    .replace(/<@!?\d+>/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

function parseAdminCommand(command) {
  const cassieMatch = String(command || '').match(/^\/?(播放cassie|播放CASSIE|cassie)\s+(?:(7777|7778|7779|一服|二服|三服)\s+)?(.+)$/i);

  if (cassieMatch) {
    let port = '7777';

    if (cassieMatch[2] === '7778' || cassieMatch[2] === '一服') port = '7778';
    else if (cassieMatch[2] === '7779' || cassieMatch[2] === '三服') port = '7779';
    else if (cassieMatch[2] === '7777' || cassieMatch[2] === '二服') port = '7777';

    return {
      action: 'cassie',
      label: '播放CASSIE',
      text: cassieMatch[3].trim(),
      port: port,
      serverLabel: serverLabel(port)
    };
  }

  const match = String(command || '').match(/^\/?(重置回合|重启回合|重开|rr|开启回合|开回合|rs|锁定回合|锁回合|rl|解锁回合|解回合|ru|开启核弹|开核|ws|关闭核弹|关核|wt|锁定核弹|锁核|wl|解锁核弹|解核|wu|刷假人|一键刷假人|一键刷15假人|刷15假人|15假人|假人|dummy)(?:\s+(7777|7778|7779|一服|二服|三服|1|2|3))?$/i);

  if (!match) return null;

  const actionMap = {
    '重置回合': 'restart',
    '重启回合': 'restart',
    '重开': 'restart',
    'rr': 'restart',
    '开启回合': 'start',
    '开回合': 'start',
    'rs': 'start',
    '锁定回合': 'lock',
    '锁回合': 'lock',
    'rl': 'lock',
    '解锁回合': 'unlock',
    '解回合': 'unlock',
    'ru': 'unlock',
    '开启核弹': 'warhead_start',
    '开核': 'warhead_start',
    'ws': 'warhead_start',
    '关闭核弹': 'warhead_stop',
    '关核': 'warhead_stop',
    'wt': 'warhead_stop',
    '锁定核弹': 'warhead_lock',
    '锁核': 'warhead_lock',
    'wl': 'warhead_lock',
    '解锁核弹': 'warhead_unlock',
    '解核': 'warhead_unlock',
    'wu': 'warhead_unlock',
    '刷假人': 'dummy',
    '一键刷假人': 'dummy15',
    '一键刷15假人': 'dummy15',
    '刷15假人': 'dummy15',
    '15假人': 'dummy15',
    '假人': 'dummy',
    'dummy': 'dummy'
  };

  let port = '7777';

  if (match[2] === '7778' || match[2] === '一服' || match[2] === '1') port = '7778';
  else if (match[2] === '7779' || match[2] === '三服' || match[2] === '3') port = '7779';
  else if (match[2] === '7777' || match[2] === '二服' || match[2] === '2') port = '7777';

  return {
    action: actionMap[match[1]],
    label: match[1],
    port: port,
    serverLabel: serverLabel(port)
  };
}

function rememberAdminOpenId(config, openId) {
  if (!openId) return;

  const list = config.adminOpenIds || [];
  if (list.includes(openId)) return;

  list.push(openId);
  config.adminOpenIds = list;

  try {
    fs.writeFileSync(CONFIG_PATH, JSON.stringify(config, null, 2), 'utf8');
    log('已将管理员 openid 加入白名单: ' + openId);
  } catch (error) {
    log('写入管理员 openid 失败: ' + error.message);
  }
}

function isAdmin(config, author) {
  if (!author) return false;

  const values = [author.id, author.member_openid, author.union_openid, author.username]
    .filter(Boolean)
    .map(String);

  const qqList = (config.adminQQ || []).map(String);
  const openIds = (config.adminOpenIds || []).map(String);

  if (values.some((value) => qqList.includes(value))) return true;
  if (author.member_openid && openIds.includes(String(author.member_openid))) return true;

  return false;
}

const RA_CONFIG_FILES = {
  7777: 'C:/Users/Administrator/AppData/Roaming/Carl Mod/config/7777/config_remoteadmin.txt',
  7778: 'C:/Users/Administrator/AppData/Roaming/Carl Mod/config/7778/config_remoteadmin.txt',
  7779: 'C:/Users/Administrator/AppData/Roaming/Carl Mod/config/7779/config_remoteadmin.txt'
};

function addAdminToRaConfig(port, uid) {
  const file = RA_CONFIG_FILES[port];
  if (!file) return { status: 'error', message: 'unknown port' };

  try {
    const text = fs.readFileSync(file, 'utf8').replace(/^\uFEFF/, '');
    const target = uid.trim().toLowerCase();
    const lines = text.split(/\r?\n/);

    for (const line of lines) {
      const m = line.match(/^\s*-\s*([^:\s]+@device)\s*:\s*(\S+)\s*$/i);
      if (m && m[1].toLowerCase() === target) return { status: 'exists', role: m[2] };
    }

    const idx = lines.findIndex(l => /^Members:\s*$/.test(l));
    if (idx < 0) return { status: 'error', message: 'Members not found' };

    lines.splice(idx + 1, 0, '  - ' + uid.trim() + ': admin');
    fs.writeFileSync(file, lines.join('\r\n'), 'utf8');
    return { status: 'added' };
  } catch (error) {
    return { status: 'error', message: error.message };
  }
}

async function handleGiveAdmin(config, groupOpenId, eventId, author, args) {
  if (!isAdmin(config, author)) {
    await sendGroupMessage(config, groupOpenId, eventId, '无管理员权限。', 1);
    return;
  }

  const parts = String(args || '').trim().split(/\s+/);
  let port = 0;
  let uid = '';

  for (const part of parts) {
    if (part === '1' || part === '一服') { port = 7778; continue; }
    if (part === '2' || part === '二服') { port = 7777; continue; }
    if (part === '3' || part === '三服') { port = 7779; continue; }
    if (!uid) uid = part;
  }

  if (!port) {
    await sendGroupMessage(config, groupOpenId, eventId,
      '请指定服务器：\n给管理 1 UID（一服 7778）\n给管理 2 UID（二服 7777）\n给管理 3 UID（三服 7779）\n示例：给管理 1 0000000000000000@device', 1);
    return;
  }

  const target = normalizeUid(uid).trim();

  if (!/@device$/i.test(target)) {
    await sendGroupMessage(config, groupOpenId, eventId,
      'UID 格式不正确，必须以 @device 结尾。\n示例：给管理 ' + (port === 7778 ? '1' : port === 7779 ? '3' : '2') + ' 0000000000000000@device', 1);
    return;
  }

  const result = addAdminToRaConfig(port, target);
  const serverText = serverLabel(port) + ' ' + port;

  const token = config.adminBridgeToken || '';
  const bridgePort = (config.adminBridgePorts || {})[port];
  let reloaded = false;

  if (bridgePort) {
    try {
      const response = await fetch('http://127.0.0.1:' + bridgePort + '/admin?token='
        + encodeURIComponent(token) + '&action=reloadra', { method: 'GET' });

      reloaded = response.ok;
    } catch (error) {
      log('给管理 reloadra 失败 ' + port + ': ' + error.message);
    }
  }

  const state = result.status === 'added'
    ? '已添加 admin'
    : result.status === 'exists'
      ? '已存在（' + result.role + '）'
      : '写入失败';

  await sendGroupMessage(config, groupOpenId, eventId,
    serverText + '：' + state + '\n' + target + '\nRA 重载：' + (reloaded ? '成功' : '失败'), 1);
  log('给管理 ' + serverText + ' ' + target + ' status=' + result.status + ' reloaded=' + reloaded);
}

async function handleAdminCommand(config, groupOpenId, eventId, command, author) {
  const parsed = parseAdminCommand(command);
  if (!parsed) return false;

  if (!isAdmin(config, author)) {
    const openId = author && author.member_openid ? author.member_openid : '未知';
    await sendGroupMessage(config, groupOpenId, eventId,
      '无管理员权限。\n你的 openid：' + openId + '\n请让开发者加入管理员白名单。', 1);
    return true;
  }

  const bridgePort = (config.adminBridgePorts || {})[parsed.port];
  const token = config.adminBridgeToken || '';

  if (!bridgePort) {
    await sendGroupMessage(config, groupOpenId, eventId, '没有配置 ' + parsed.port + ' 的管理接口。', 1);
    return true;
  }

  if (parsed.action === 'dummy15') {
    let sent = 0;

    for (let i = 0; i < 15; i++) {
      try {
        const response = await fetch('http://127.0.0.1:' + bridgePort + '/admin?token='
          + encodeURIComponent(token) + '&action=dummy', { method: 'GET' });

        if (response.ok) sent++;
      } catch (error) {
        log('一键刷15假人失败: ' + error.message);
      }
    }

    await sendGroupMessage(config, groupOpenId, eventId,
      '已一键刷假人：' + sent + '/15\n目标：' + parsed.port + ' ' + parsed.serverLabel, 1);
    log('一键刷15假人 -> ' + parsed.port + ' success=' + sent);
    return true;
  }

  try {
    const response = await fetch('http://127.0.0.1:' + bridgePort + '/admin?token='
      + encodeURIComponent(token) + '&action=' + encodeURIComponent(parsed.action)
      + (parsed.action === 'cassie' ? '&text=' + encodeURIComponent(parsed.text) : ''),
      { method: 'GET' });

    const text = await response.text();

    if (!response.ok) {
      await sendGroupMessage(config, groupOpenId, eventId,
        '执行失败：' + parsed.label + '（' + parsed.port + ' ' + parsed.serverLabel + '）\n' + text.slice(0, 200), 1);
      return true;
    }

    await sendGroupMessage(config, groupOpenId, eventId,
      '已执行：' + parsed.label + (parsed.action === 'cassie' ? '（' + parsed.text + '）' : '')
      + '\n目标：' + parsed.port + ' ' + parsed.serverLabel + '\n' + text, 1);
    log('管理员指令 ' + parsed.label + ' -> ' + parsed.port + ' action=' + parsed.action + ' by ' + (author.member_openid || author.id || '?'));
  } catch (error) {
    await sendGroupMessage(config, groupOpenId, eventId,
      '执行失败：' + parsed.label + '\n' + error.message, 1);
    log('管理员指令失败: ' + error.message);
  }

  return true;
}

function buildAdminHelp() {
  return '管理员指令（1=一服7778，2=二服7777，3=三服7779）：\n'
    + '重开 1|2|3\n'
    + '开回合 1|2|3\n'
    + '锁回合 1|2|3\n'
    + '解回合 1|2|3\n'
    + '开核 1|2|3\n'
    + '关核 1|2|3\n'
    + '锁核 1|2|3\n'
    + '解核 1|2|3\n'
    + '假人 1|2|3\n'
    + '一键刷15假人 1|2|3\n'
    + '播放CASSIE .G7 1|2|3';
}

function makeReply(config, content) {  if (!content) return null;

  const command = normalizeCommand(content);

  if (/^(\/)?(击杀榜|排行榜|rank|killrank)(\s|$)/i.test(command)) {
    let port = 7777;
    if (/(7778|一服|1服)/.test(command)) port = 7778;
    else if (/(7779|三服|3服)/.test(command)) port = 7779;
    else if (/(7777|二服|2服)/.test(command)) port = 7777;
    return buildLeaderboard(config, port);
  }

  if (/^(\/)?(一服击杀榜|二服击杀榜|三服击杀榜)(\s|$)/i.test(command)) {
    const port = /三服/.test(command) ? 7779 : (/一服/.test(command) ? 7778 : 7777);
    return buildLeaderboard(config, port);
  }

  if (/^(\/)?(关于|关于机器人|about|机器人信息)(\s|$)/i.test(command)) {
    return '关于机器人\n'
      + '名称：SEC官服查询机器人\n'
      + '开发者：wdf\n'
      + '操作平台：Windows\n'
      + '功能：击杀榜、在线人数、总击杀榜';
  }

  if (/^(\/)?(手机击杀榜|手机榜)(\s|$)/i.test(command)) {
    return buildMobileLeaderboard(config);
  }

  if (/^(\/)?(pc击杀榜|pc榜|pcrank)(\s|$)/i.test(command)) {
    return buildPcLeaderboard(config);
  }

  if (/^(\/)?(帮助|help|指令)(\s|$)/i.test(command)) {
    return '查询指令：\n'
      + '在线人数 / /cx（人数+击杀榜截图，含三服）\n'
      + '玩家名单（在线玩家名字截图，含三服）\n'
      + '击杀榜 / 一服击杀榜 / 二服击杀榜 / 三服击杀榜\n'
      + '击杀榜 一服|二服|三服（或 击杀榜 1|2|3）\n'
      + 'PC击杀榜 / pc榜 / 手机击杀榜\n'
      + '/kd（查询等级、经验、服务器、排名、击杀）\n'
      + '/绑定 验证码（游戏控制台 .yzd 获取，5分钟有效）\n'
      + '/解绑（解除绑定）\n'
      + '关于机器人\n\n'
      + '管理员指令（1=一服7778，2=二服7777，3=三服7779）：\n'
      + '重开 1|2|3\n'
      + '开回合 1|2|3\n'
      + '锁回合 1|2|3\n'
      + '解回合 1|2|3\n'
      + '开核 1|2|3\n'
      + '关核 1|2|3\n'
      + '锁核 1|2|3\n'
      + '解核 1|2|3\n'
      + '假人 1|2|3\n'
      + '播放CASSIE .G7 1|2|3';
  }

  return null;
}

const MSG_SEQ = new Map();

/// 同一条群消息（msg_id）下的多条回复必须用各自递增的 msg_seq，
/// 重复用同一个 seq 会被 QQ 判为重复消息直接拒绝（表现为"机器人不回"）。
function nextMsgSeq(eventId) {
  if (!eventId) return Math.floor(Math.random() * 1000000) + 1;

  const key = String(eventId);
  const n = (MSG_SEQ.get(key) || 0) + 1;
  MSG_SEQ.set(key, n);

  if (MSG_SEQ.size > 800) {
    const first = MSG_SEQ.keys().next().value;
    MSG_SEQ.delete(first);
  }

  return n;
}

async function sendGroupMessage(config, groupOpenId, eventId, content, seq) {
  const body = {
    content: content,
    msg_type: 0,
    msg_seq: nextMsgSeq(eventId)
  };

  if (eventId) body.msg_id = eventId;

  const token = await getAccessToken(config);

  const response = await fetch(apiBase() + '/v2/groups/' + encodeURIComponent(groupOpenId) + '/messages', {
    method: 'POST',
    headers: {
      'Authorization': 'QQBot ' + token,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(body)
  });

  const text = await response.text();

  if (!response.ok) {
    throw new Error('发送群消息失败: HTTP ' + response.status + ' ' + text.slice(0, 500));
  }

  log('已发送群消息 group=' + groupOpenId + ' len=' + String(content || '').length);

  return text;
}

function saveConfig(config) {
  fs.writeFileSync(CONFIG_PATH, JSON.stringify(config, null, 2), 'utf8');
}

function rememberGroup(config, groupOpenId) {
  if (!groupOpenId) return;

  if (!Array.isArray(config.groupOpenIds)) config.groupOpenIds = [];

  if (!config.groupOpenIds.includes(groupOpenId)) {
    config.groupOpenIds.push(groupOpenId);

    try { saveConfig(config); } catch (error) { log('保存群列表失败: ' + error.message); }
  }
}

function buildCommunityEndText(config) {
  const rows = readRanking(config);
  const labels = ['第一名', '第二名', '第三名', '第四名'];
  const lines = ['社区赛最终排名'];

  for (let i = 0; i < 4 && i < rows.length; i++) {
    lines.push(labels[i] + '：' + rows[i].name + '（' + rows[i].server + '） ' + rows[i].points + ' 分');
  }

  lines.push('社区赛结束');
  return lines.join('\n');
}

async function checkCommunityEnd(config) {
  if (!config || !config.communityEndHour) return;

  const now = new Date();
  if (now.getHours() < config.communityEndHour) return;

  const today = now.getFullYear() + '-' + String(now.getMonth() + 1).padStart(2, '0') + '-' + String(now.getDate()).padStart(2, '0');
  if (config.communityEndSent === today) return;

  const groups = Array.isArray(config.groupOpenIds) ? config.groupOpenIds.slice() : [];
  const text = buildCommunityEndText(config);
  let sent = 0;

  // 不发主动公告；等群里有人互动时用普通消息发送。
  config.communityEndSent = today;
  config.communityEndPending = groups.length > 0;
  config.communityEndNotifiedGroups = [];

  try { saveConfig(config); } catch (error) { log('保存社区赛状态失败: ' + error.message); }

  log('社区赛结束，等待群互动后用普通消息发送（群数=' + groups.length + '）');

  try {
    execFileSync(process.execPath, [path.join(ROOT, 'sync-panel.js')], {
      cwd: ROOT,
      env: Object.assign({}, process.env, { COMMUNITY_END: '1' }),
      timeout: 120000,
      stdio: 'ignore'
    });
    log('社区赛后面板已切换为 PC端击杀榜');
  } catch (error) {
    log('切换面板失败: ' + error.message);
  }
}

function startCommunityScheduler(config) {
  let busy = false;

  const run = async () => {
    if (busy) return;
    busy = true;

    try { await checkCommunityEnd(config); } catch (error) { log('社区赛定时任务失败: ' + error.message); }

    busy = false;
  };

  run();
  const timer = setInterval(run, 15000);
  if (timer.unref) timer.unref();
}

let heartbeatTimer = null;
let lastFrameAt = Date.now();
let socket = null;
let reconnectTimer = null;
let lastSeq = null;
let closing = false;

function clearTimers() {
  if (heartbeatTimer) {
    clearInterval(heartbeatTimer);
    heartbeatTimer = null;
  }
  if (reconnectTimer) {
    clearTimeout(reconnectTimer);
    reconnectTimer = null;
  }
}

async function connect(config) {
  if (closing) return;

  try {
    const token = await getAccessToken(config);

    let gatewayResponse = await fetch(apiBase() + '/gateway/bot', {
      headers: { 'Authorization': 'QQBot ' + token }
    });

    let gatewayText = await gatewayResponse.text();

    if (!gatewayResponse.ok) {
      gatewayResponse = await fetch(apiBase() + '/gateway', {
        headers: { 'Authorization': 'QQBot ' + token }
      });
      gatewayText = await gatewayResponse.text();
    }

    let gateway;

    try {
      gateway = JSON.parse(gatewayText);
    } catch (_) {
      throw new Error('获取 gateway 返回非 JSON: ' + gatewayText.slice(0, 300));
    }

    if (!gatewayResponse.ok || !gateway.url) {
      throw new Error('获取 gateway 失败: HTTP ' + gatewayResponse.status + ' ' + gatewayText.slice(0, 500));
    }

    const shardCount = Math.max(1, Number(gateway.shards || 1));
    const shard = [0, shardCount];

    log('连接 gateway: ' + gateway.url);
    socket = new WebSocket(gateway.url);

    socket.addEventListener('open', () => {
      log('WebSocket 已连接，等待 Hello');
    });

    socket.addEventListener('message', async (event) => {
      let payload;

      try {
        payload = JSON.parse(event.data);
      } catch (_) {
        return;
      }

      try {
      if (payload.s !== undefined && payload.s !== null) lastSeq = payload.s;
      lastFrameAt = Date.now();

      if (payload.op === 10) {
        const interval = Number(payload.d && payload.d.heartbeat_interval) || 30000;

        socket.send(JSON.stringify({
          op: 2,
          d: {
            token: 'QQBot ' + token,
            intents: Number(config.intents || 33554432),
            shard: shard,
            properties: {
              $os: 'windows',
              $browser: 'carlx-qqbot',
              $device: 'carlx-qqbot'
            }
          }
        }));

        if (heartbeatTimer) clearInterval(heartbeatTimer);
        heartbeatTimer = setInterval(() => {
          try {
            if (socket && socket.readyState === WebSocket.OPEN) {
              // 超过 2.5 个心跳周期一个包都没收到 → 连接已经僵死，主动重连。
              // 否则表现为"机器人不理人"但没有任何报错。
              const silentMs = Date.now() - lastFrameAt;
              if (silentMs > interval * 2.5) {
                log('心跳超时（' + Math.round(silentMs / 1000) + '秒未收到任何数据），主动重连');
                try { socket.close(); } catch (_) { }
                return;
              }

              socket.send(JSON.stringify({ op: 1, d: lastSeq }));
            }
          } catch (_) {
          }
        }, interval);

        log('已发送 Identify，心跳间隔=' + interval + 'ms');
        return;
      }

      if (payload.op === 11) return;

      if (payload.op === 7) {
        log('服务端要求重连');
        try { socket.close(); } catch (_) { }
        return;
      }

      if (payload.op === 9) {
        log('Identify 无效，稍后重连');
        try { socket.close(); } catch (_) { }
        return;
      }

      if (payload.op !== 0 || !payload.t) return;

      if (payload.t === 'READY') {
        const readyUser = payload.d && payload.d.user ? payload.d.user.username : '?';
        log('READY，机器人已登录: ' + readyUser + '，session=' + (payload.d && payload.d.session_id ? payload.d.session_id : '?'));
        return;
      }

      if (payload.t === 'RESUMED') {
        log('RESUMED，会话已恢复');
        return;
      }

      if (payload.t !== 'GROUP_AT_MESSAGE_CREATE') return;

      const data = payload.d || {};
      const groupOpenId = data.group_openid;
      const eventId = data.id;

      if (!groupOpenId) return;

      log('收到群消息 group=' + groupOpenId + ' author=' + (data.author && data.author.id ? data.author.id : '?') + ' content=' + JSON.stringify(String(data.content || '').slice(0, 80)));

      rememberGroup(config, groupOpenId);

      if (config.communityEndPending && eventId) {
        if (!Array.isArray(config.communityEndNotifiedGroups)) config.communityEndNotifiedGroups = [];

        if (!config.communityEndNotifiedGroups.includes(groupOpenId)) {
          try {
            await sendGroupMessage(config, groupOpenId, eventId, buildCommunityEndText(config), 1);
            config.communityEndNotifiedGroups.push(groupOpenId);
            if (config.communityEndNotifiedGroups.length >= (config.groupOpenIds || []).length) {
              config.communityEndPending = false;
            }
            saveConfig(config);
            log('社区赛结束信息已发送到群 ' + groupOpenId);
          } catch (error) {
            log('社区赛结束信息发送失败 ' + groupOpenId + ': ' + error.message);
          }
        }
      }

      const command = normalizeCommand(data.content);

      if (/^\d{6}$/.test(command)) {
        await handleCodeBind(config, groupOpenId, eventId, data.author || {}, command);
        return;
      }

      const bindMatch = command.match(/^\/?(?:绑定|绑定账号|绑定uid|bind)\s*(.*)$/i);
      if (bindMatch) {
        const code = (bindMatch[1] || '').trim();

        if (/^\d{6}$/.test(code)) {
          await handleCodeBind(config, groupOpenId, eventId, data.author || {}, code);
          return;
        }

        await sendGroupMessage(config, groupOpenId, eventId,
          '绑定方式已改为验证码。\n1. 在游戏控制台输入：.yzd\n2. 获取 6 位验证码（5 分钟有效）\n3. 在群里发送：/绑定 验证码', 1);
        return;
      }

      const applyMatch = command.match(/^\/?(?:申请测试服|申请测试|测试服申请)\s*(.*)$/i);
      const bareUid = !applyMatch && /^[A-Za-z0-9]{8,}@device$/i.test(command) ? command : null;
      if (applyMatch || bareUid) {
        const rawUid = applyMatch ? (applyMatch[1] || '').trim() : bareUid;
        const uid = normalizeUid(rawUid);

        if (!uid) {
          await sendGroupMessage(config, groupOpenId, eventId,
            '请发送：申请测试服 你的游戏UID\n示例：申请测试服 0000000000000000@device', 1);
          return;
        }

        if (!/@device$/i.test(uid)) {
          await sendGroupMessage(config, groupOpenId, eventId,
            'UID 格式不正确，必须以 @device 结尾。\n示例：申请测试服 0000000000000000@device', 1);
          return;
        }

        const result = addTestWhitelistUid(uid);

        if (result === 'added') {
          await sendGroupMessage(config, groupOpenId, eventId,
            '已加入测试服白名单：\n' + uid + '\n现在可以进入一服（7778）。', 1);
          log('测试服白名单已添加: ' + uid);
        } else if (result === 'exists') {
          await sendGroupMessage(config, groupOpenId, eventId,
            '该 UID 已经在测试服白名单中：\n' + uid, 1);
        } else {
          await sendGroupMessage(config, groupOpenId, eventId,
            '加入白名单失败，请稍后重试。', 1);
        }
        return;
      }

      if (/^\/?(解绑|unbind)(\s|$)/i.test(command)) {
        const bindings = loadBindings();
        const bindKey = bindingKey(data.author || {});
        if (bindKey && bindings[bindKey]) {
          delete bindings[bindKey];
          saveBindings(bindings);
          await sendGroupMessage(config, groupOpenId, eventId, '已解除 UID 绑定。', 1);
        } else {
          await sendGroupMessage(config, groupOpenId, eventId, '你还没有绑定账号。', 1);
        }
        return;
      }

      if (/^\/?(kd|查询kd|我的kd|战绩|kd查询)(\s|$)/i.test(command)) {
        await handleKd(config, groupOpenId, eventId, data.author || {});
        return;
      }

      if (/^wdf牛逼不[?？!！。]*$/i.test(command)) {
        await sendGroupMessage(config, groupOpenId, eventId, 'wdf不牛逼整天就知道研究一些插件和bug', 1);
        return;
      }

      const giveAdminMatch = command.match(/^\/?(?:给管理|设置管理|添加管理|addadmin)\s+(.+)$/i);
      if (giveAdminMatch) {
        await handleGiveAdmin(config, groupOpenId, eventId, data.author || {}, giveAdminMatch[1].trim());
        return;
      }

      if (parseAdminCommand(command)) {
        await handleAdminCommand(config, groupOpenId, eventId, command, data.author || {});
        return;
      }

      if (/^\/?(管理员|管理)\s*指令$/i.test(command)) {
        if (!isAdmin(config, data.author || {})) {
          await sendGroupMessage(config, groupOpenId, eventId, '无管理员权限。', 1);
          return;
        }

        await sendGroupMessage(config, groupOpenId, eventId, buildAdminHelp(), 1);
        return;
      }

      if (/^\/?(手机击杀榜|手机榜)(\s|$)/i.test(command)) {
        await handlePlatformRank(config, groupOpenId, eventId, 'mobile');
        return;
      }

      if (/^\/?(pc端击杀榜|pc击杀榜|pc榜|pcrank)(\s|$)/i.test(command)) {
        await handlePlatformRank(config, groupOpenId, eventId, 'pc');
        return;
      }

      if (/^\/?(玩家名单|在线名单|名单|玩家列表|playerlist|players)(\s|$)/i.test(command)) {
        await handlePlayers(config, groupOpenId, eventId);
        return;
      }

      if (/^\/?(cx|在线人数|服务器人数|查询人数)(\s|$)/i.test(command)) {
        await handleCx(config, groupOpenId, eventId);
        return;
      }

      const reply = makeReply(config, data.content);

      if (!reply) {
        if (/^\//.test(command)) {
          try {
            await sendGroupMessage(config, groupOpenId, eventId, '未识别的指令，发送「帮助」查看用法。', 1);
          } catch (error) {
            log(error.message);
          }
        }
        return;
      }

      try {
        await sendGroupMessage(config, groupOpenId, eventId, reply, 1);
        log('已回复群 ' + groupOpenId + '，事件 ' + (eventId || '?'));
      } catch (error) {
        log(error.message);
      }
      } catch (error) {
        // 任何异常都不能让这条消息"石沉大海"：记日志，并尽量给用户一个回复
        log('消息处理异常: ' + (error && error.stack ? error.stack : error));

        try {
          const data2 = payload && payload.d ? payload.d : {};
          if (data2.group_openid && data2.id) {
            await sendGroupMessage(config, data2.group_openid, data2.id, '机器人处理这条指令时出错了，请稍后重试。', 1);
          }
        } catch (_) {
        }
      }
    });

    socket.addEventListener('close', (event) => {
      log('WebSocket 关闭: code=' + event.code + ' reason=' + (event.reason || ''));
      clearTimers();
      if (!closing) {
        reconnectTimer = setTimeout(() => connect(config), 5000);
      }
    });

    socket.addEventListener('error', (event) => {
      log('WebSocket 错误: ' + (event.message || 'unknown'));
    });
  } catch (error) {
    log(error.message);
    clearTimers();
    if (!closing) {
      reconnectTimer = setTimeout(() => connect(config), 10000);
    }
  }
}

function main() {
  let config;

  try {
    config = loadConfig();
  } catch (error) {
    console.error('读取 config.json 失败: ' + error.message);
    process.exit(1);
  }

  QQ_APP_ID = String(config.appId || '');
  log('QQ官方群机器人启动中');
  connect(config);

  // 兜底：任何未捕获的异步异常都要进日志，避免"消息没回复也查不到原因"
  process.on('unhandledRejection', (reason) => {
    log('未处理的异步异常: ' + (reason && reason.stack ? reason.stack : reason));
  });

  process.on('uncaughtException', (error) => {
    log('未捕获异常: ' + (error && error.stack ? error.stack : error));
  });

  process.on('SIGINT', () => {
    closing = true;
    clearTimers();
    try { if (socket) socket.close(); } catch (_) { }
    process.exit(0);
  });

  process.on('SIGTERM', () => {
    closing = true;
    clearTimers();
    try { if (socket) socket.close(); } catch (_) { }
    process.exit(0);
  });

  process.on('unhandledRejection', (error) => {
    log('未处理的异步异常: ' + (error && error.stack ? error.stack : error));
  });

  process.on('uncaughtException', (error) => {
    log('未捕获异常(已忽略，进程继续运行): ' + (error && error.stack ? error.stack : error));
  });
}

if (require.main === module) {
  main();
}

module.exports = {
  readOnlineCount,
  buildCxHtml,
  screenshotCx,
  screenshotPlayers,
  screenshotPlatformRank,
  readMobileRanking,
  readPcRanking,
  getKdData,
  screenshotKd,
  buildKdHtml,
  findBindCode,
  handleCodeBind,
  addTestWhitelistUid,
  addAdminToRaConfig
};
